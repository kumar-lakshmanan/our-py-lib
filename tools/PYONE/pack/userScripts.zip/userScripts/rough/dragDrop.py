from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import dragDrop
#For DevConsole

class dragDropCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=dragDrop.__file__.replace(".py",".ui")
		super(dragDropCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)
		#self.pushButton.clicked.connect(self.doRun)
		
	def initialize(self):
		self.parent.pylib.say("dragDropClsObj is working fine")

	def doRun(self):
		input = self.textEdit.toPlainText()
		self.label.setText(input)
		self.parent.pylib.say(input)

if (__name__=="__main__"):
	if(not hasattr(dev,'dragDropClsObj') or sip.isdeleted(dev.dragDropClsObj)):
		dev.dragDropClsObj = dragDropCls(dev)
	dev.dragDropClsObj.show()
	dev.dragDropClsObj.raise_()