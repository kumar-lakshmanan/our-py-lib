'''
#For DevConsole
'''
import dfg


class trekCls():
	
	def __init__(self):
		print('this is trek using dfg - zmx')
		
	def runr(self):
		print('runernem')
		z = dfg.dfgCls()
		z.runme()
