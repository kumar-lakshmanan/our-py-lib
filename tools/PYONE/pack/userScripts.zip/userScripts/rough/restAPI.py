'''
#For DevConsole
'''
import http.client
import json
import url

class restAPICls():
	
	def __init__(self,parent):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.parent.pylib.say("restAPICls is ready!")

	def initialize(self):
		self.parent.pylib.say("restAPICls initialized!")
		host = 'en.wikipedia.org'
		uri = '/w/api.php?action=query&titles=Main%20Page&prop=revisions&rvprop=content&format=json'
		conn = http.client.HTTPSConnection(host)
		conn.request("GET", uri)
		r1 = conn.getresponse()
		print(r1.status, r1.reason)
		data = str(r1.read(),'utf-8')
		j = json.loads(data)
		print(j['query'])
		
		

if __name__ == '__main__':
	dev.restAPIClsObj = restAPICls(dev)
	dev.restAPIClsObj.initialize()
