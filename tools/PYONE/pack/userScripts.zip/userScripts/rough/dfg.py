'''
#For DevConsole
'''


class dfgCls():
	
	def __init__(self):
		print('this is dfg - xmy')
		
	def runme(self):
		print('df5555dghtd')

