'''
#For DevConsole
'''

from pysimplesoap.client import SoapClient
from pysimplesoap.simplexml import SimpleXMLElement
from requests.utils import DEFAULT_CA_BUNDLE_PATH;
import tempfile
import ssl 

cacertPem ='C:\\Users\\p693490\\Desktop\\Testing\\Tools\\PyOne\\cacert.pem'
url = "https://10.40.253.13:5550/service/mgmt/amp/3.0"
ns = "http://www.datapower.com/schemas/appliance/management/3.0"
basicAuth = {'Authorization':'Basic cDcyOTQ2NWQ6SmFuNDEzMiU='}

ssl._create_default_https_context = ssl._create_unverified_context
print(DEFAULT_CA_BUNDLE_PATH)

gc = ssl._create_unverified_context()
gc = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
print(gc.load_default_certs())
print(gc.get_ca_certs())

client = SoapClient(location=url,namespace=ns,trace=True)
client.http_headers = basicAuth

params = SimpleXMLElement("""<?xml version="1.0" encoding="UTF-8"?>
<GetDomainListRequest xmlns="http://www.datapower.com/schemas/appliance/management/3.0"/>
""", namespace=ns)
response = client.call('GetDomainListRequest',params)

print('\n')
print(response.as_xml())
print('\n')
