'''
#For DevConsole
'''
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
import time

class myThread(QtCore.QThread):
	
	def __init__(self, inputs,slp):
		QtCore.QThread.__init__(self)
		self.inputs = inputs
		self.slp = slp

	def __del__(self):
		self.wait()

	def run(self):
		print('Started' + self.inputs)
		for i in range(0,10):
			time.sleep(1)
			print('In Thread.' +self.inputs + '..' + str(i))

dev.mytobj = myThread('inpu',2)	
dev.mytobj.start()
print("THATS GOING SOME WHERE")


