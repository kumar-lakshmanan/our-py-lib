'''
#For DevConsole
'''
from suds.client import Client
from xmljson import BadgerFish  
from xml.etree.ElementTree import fromstring
from suds.sax.text import Raw
import json
from suds.transport.https import HttpAuthenticated
from suds.xsd.doctor import ImportDoctor, Import
from suds.client import Client

import base64

# code excluded for brevity

'''
base64string = base64.encodestring('%s:%s' % (username, password)).replace('\n', '')
authenticationHeader = {
    "SOAPAction" : "ActionName",
    "Authorization" : "Basic %s" % base64string
}
client = Client(url=wsdl_url, headers=authenticationHeader)
'''

url = 'http://www.webservicex.net/country.asmx?WSDL'

client = Client(url)
#client = Client('http://localhost:8181/soap/helloservice?wsdl', username='bob', password='catbob')
result = client.service.GetCountryByCurrencyCode('USD')

bf_str1 = BadgerFish()
rs = bf_str1.data(fromstring(result))

print(rs)
response = json.loads(json.dumps(rs))
print(response)
print('--')
print(response['NewDataSet']['Table'][0]['Name']['$'])
print(response['NewDataSet']['Table'][0]['Currency']['$'])
print(response['NewDataSet']['Table'][0]['CurrencyCode']['$'])
print(response['NewDataSet']['Table'][0]['CountryCode']['$'])
print('--')
