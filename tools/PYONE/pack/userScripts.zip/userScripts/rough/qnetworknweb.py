'''
#For DevConsole
'''


from PyQt5.QtCore import QFile, QIODevice, Qt, QTextStream, QUrl
from PyQt5.QtWidgets import (QAction, QApplication, QLineEdit, QMainWindow, QSizePolicy, QStyle, QTextEdit)
from PyQt5.QtNetwork import QNetworkProxyFactory, QNetworkRequest
from PyQt5.QtWebKitWidgets import QWebPage, QWebView

class qnetworknwebCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.parent.pylib.say("qnetworknwebCls is ready!")

	def initialize(self):
		self.url = QUrl('http://127.0.0.1:8082/testing/mores')
		QNetworkProxyFactory.setUseSystemConfiguration(True)
		self.parent.view = QWebView()
		self.parent.view.load(self.url)
		self.parent.view.show()
		self.parent.view.loadFinished.connect(self.finishLoading)
		
		self.parent.pylib.say("qnetworknwebCls initialized!")
		
	def finishLoading(self):
		accessManager = self.parent.view.page().networkAccessManager()
		request = QNetworkRequest(self.parent.view.url())
		reply = accessManager.get(request)
		reply.finished.connect(self.slotSourceDownloaded)	
		#sc = QScriptEngine()
		#res = sc.evaluvate('1+3')
		#print(res)

	def slotSourceDownloaded(self):
		reply = self.parent.sender()
		self.textEdit = QTextEdit()
		self.textEdit.setAttribute(Qt.WA_DeleteOnClose)
		self.textEdit.show()
		self.textEdit.setPlainText(QTextStream(reply).readAll())
		self.textEdit.resize(600, 400)
		reply.deleteLater()	
		

if __name__ == '__main__':
	dev.qnetworknwebClsObj = qnetworknwebCls(dev)
	dev.qnetworknwebClsObj.initialize()
