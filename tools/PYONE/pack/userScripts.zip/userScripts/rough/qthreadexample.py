'''
#For DevConsole
'''



import time
import sys
import gc
import os
import platform

import sip
from PyQt5.QtCore import QT_VERSION_STR
from PyQt5.Qt import PYQT_VERSION_STR
from PyQt5.QtCore import QObject, QThread, pyqtSignal, pyqtSlot
from PyQt5.QtCore import qDebug, Qt
from PyQt5.QtWidgets import QApplication, QWidget

# Change to set the type of object passed between threads.
objType = QObject

def printObject(obj):
    qDebug('{} {:#X} {}'.format(type(obj), id(obj), obj))

class SomeThread(QObject):
    signal = pyqtSignal(objType)

    def __init__(self):
        QObject.__init__(self)
        self.thread = QThread()
        self.wait = self.thread.wait
        self.moveToThread(self.thread)
        self.signal.connect(self.signalHandler, type = Qt.QueuedConnection)
        self.thread.started.connect(self.run)
        self.thread.start()

    @pyqtSlot(objType)
    def signalHandler(self, obj):
        qDebug('In signalHandler.')
        printObject(obj)
        qDebug("signalHandler obj ref counts: " + str(sys.getrefcount(obj)))

    @pyqtSlot()
    def run(self):
        qDebug("Thread sleeps for 0.1 sec")
        time.sleep(0.1)
        qDebug("Process events now")
        QApplication.processEvents()
        self.thread.exit()

def someFunc(objType, th):
    obj = objType()
    printObject(obj)
    qDebug("obj ref counts before emit: " + str(sys.getrefcount(obj)))
    th.signal.emit(obj)
    qDebug("obj ref counts after emit: " + str(sys.getrefcount(obj)))

app = None
def main():
    print('Qt {}, SIP {}, PtQt {}, Python {}, OS {}, platform {}
{}\n'.format(
      QT_VERSION_STR, sip.SIP_VERSION_STR, PYQT_VERSION_STR, sys.version,
      os.name, platform.system(), platform.release()))

    global app
    app = QApplication([])
    for x in range(100):
        print('\n\nTest {}'.format(x + 1))
        testType(objType)

def testType(objType):
    th = SomeThread()

    someFunc(objType, th)
    gc.collect()
    th.thread.wait()

if __name__ == '__main__':
    main()
