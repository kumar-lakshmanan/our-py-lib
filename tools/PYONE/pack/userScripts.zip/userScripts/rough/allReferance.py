'''
#For DevConsole
'''
#--------Threading-------
def runMe():
	for i in range(0,10):
		time.sleep(.5)
		print('ok:'+str(i))

def runMe2():
	for i in range(0,10):
		time.sleep(.8)
		print('okx:'+str(i))


t=threading.Thread(target=runMe,args=())
t2=threading.Thread(target=runMe2,args=())
t.start()
t2.start()
#--------Threading-------


#--------Transform-------
def _tempFile(self):
	f = open('temp/res.xml','r')
	data = f.read().replace('\n','').replace('\n','')
	xx = xml.dom.minidom.parseString(data) # or xml.dom.minidom.parseString(xml_string)
	pretty_xml_as_string = xx.toprettyxml()		
	f.close()
	return pretty_xml_as_string
	
#--------Transform-------