from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sys
import sip
import HTTPWebServer
#For DevConsole

from http.server import BaseHTTPRequestHandler, HTTPServer
import HTTPWebServerLogic as coreLogicServer
import threading

import importlib 
importlib.reload(coreLogicServer)
		
class CustomLog:
	def __init__(self, textEditor):
		#QTextEdit
		self.edit = textEditor
	
	def write(self, data):
		data = data.replace("\\", "\\\\")
		self.edit.moveCursor(QtGui.QTextCursor.End)
		self.edit.insertPlainText(str(data))
		vsb = self.edit.verticalScrollBar()
		vsb.setValue(vsb.maximum())    
		hsb = self.edit.horizontalScrollBar()
		hsb.setValue(0)  
				
class HTTPWebServerCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=HTTPWebServer.__file__.replace(".py",".ui")
		super(HTTPWebServerCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)

		self.oldStdOut = sys.stdout
		self.oldStdErr = sys.stderr			
		
		sys.stdout = CustomLog(self.output)	
		sys.stderr = CustomLog(self.output)	
		
		self.startBt.clicked.connect(self.start)
		self.stopBt.clicked.connect(self.stop)

		self.webAddress=('127.0.0.1', 8082)		
		self.server = HTTPServer(self.webAddress, coreLogicServer.httpRequestHandler)
		self.thread = threading.Thread(target = self.server.serve_forever)
		self.thread.daemon = True
		
		self.serverState = 'Stop'
	
	def displayStartOfServer(self):
		print("Starting server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))	

	def displayStopOfServer(self):
		print("Server Shutdown...." + str(self.webAddress))
		print("No More Connections processed!")
				
	def start(self):
		if self.serverState=='Stop':
			self.displayStartOfServer()
			QApplication.processEvents()
			self.parent.setVisible(0)
			self.thread.start()		
			self.serverState = 'Start'
		QApplication.processEvents()
		
	def stop(self):	
		if self.serverState=='Start':			
			self.server.socket.close()	
			print('Socket Closed!')
			QApplication.processEvents()			
			self.server.server_close()	
			print('Server Closed!')
			QApplication.processEvents()			
			#res = http.client.HTTPConnection(self.webAddress[0],self.webAddress[1])
			#print('Fake Connecion '+str(res))
			#QApplication.processEvents()			
			print('Please, Wait... Shutting down the server!')
			QApplication.processEvents()
			#self.server.shutdown()
			self.server.shutdown_request(self.server.socket)
			print('Server Shutdown!')
			QApplication.processEvents()			
			del(self.server)
			print('Server Deleted!')
			QApplication.processEvents()			
			del(self.thread)
			print('Thread Deleted!')
			QApplication.processEvents()			
			self.parent.setVisible(1)			
			self.displayStopOfServer()
			self.serverState = 'Stop'
		QApplication.processEvents()
	
	def closeEvent(self, event):
		if self.serverState=='Start':
			self.stop()
		sys.stdout = self.oldStdOut
		sys.stderr = self.oldStdErr
		del(self)
		print('Server closed')
		event.accept()		
		QApplication.processEvents()
	
	def __del__(self):
		self.closeEvent()

if (__name__=="__main__"):
	dev.HTTPWebServerClsObj = HTTPWebServerCls(dev)	
	dev.HTTPWebServerClsObj.show()