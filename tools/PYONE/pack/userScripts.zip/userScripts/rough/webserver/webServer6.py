'''
#For DevConsole
'''
import pyOneShortcuts

from http.server import BaseHTTPRequestHandler, HTTPServer
import serverAct.webServerFn as coreLogicServer
import sys

from PyQt5.QtCore import QObject, QThread, pyqtSignal, pyqtSlot
from PyQt5.QtWidgets import QApplication, QWidget

import importlib 
importlib.reload(coreLogicServer)

class HttpDaemon(QtCore.QThread):

	def run(self):
		print("Starting server....")
		self.webAddress=('127.0.0.1', 8082)
		print("Running server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))		
		self._server = HTTPServer(self.webAddress, coreLogicServer.httpRequestHandler)		
		self._server.serve_forever()
		QApplication.processEvents()

	def stop(self):
		self._server.shutdown()
		self._server.socket.close()
		self.wait()

dev.httpd = HttpDaemon()
dev.httpdshort = pyOneShortcuts.pyOneShortcutsCls(dev)
dev.httpdshortbtn = dev.httpdshort.doQuickShortcutWithIcon('StopServer', None, 'butterfly.png')
dev.httpdshortbtn.triggered.connect(dev.httpd.stop)
dev.httpd.start()