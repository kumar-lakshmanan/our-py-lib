'''
#For DevConsole
'''
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import threading
import pyOneShortcuts
import sip
import importlib 
import serverAct.webServerFn as coreLogicServer
from _ast import arg


class PyWebService():
	
	def __init__(self,parent):
		self.parent=parent
		self.webAddress=('127.0.0.1', 8082)
		self.webThread=None
		self.webHandle=None
		
		self.pyshort = pyOneShortcuts.pyOneShortcutsCls(self.parent)
		self.stopper = self.pyshort.doQuickShortcutWithIcon('StopServer', None, 'butterfly.png')
		self.stopper.toggled.connect(self.stopServer)
		self.stopper.setCheckable(True)		
		
	def startServer(self):
		self.pyThread = threading
		self._stopFlag = self.pyThread.Event()
		self.webThread=threading.Thread(name = 'pyWebServer', target = self._coreWebStarter, args = ())
		self.webThread.start() 		

	def _coreWebStarter(self, callBackFn):		
		importlib.reload(coreLogicServer)
		print("Starting server....")
		self.webHandle=HTTPServer(self.webAddress, coreLogicServer.httpRequestHandler)
		print("Running server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))
		try:
			self.webHandle.serve_forever()
		except:
			print ("Error Crashed")
			
		if(callBackFn):	callBackFn(self.webHandle)
	
	def stopServer(self):
		print('Stopping..!')
		self._stopFlag.set()
		del(self.webThread)
		sip.delete(self.stopper)
		self.webHandle.socket.close()
		del(self.webHandle)
		print('Stopped!')



p = PyWebService(dev)
p.startServer()