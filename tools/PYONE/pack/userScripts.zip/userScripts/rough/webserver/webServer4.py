'''
#For DevConsole
'''

from http.server import BaseHTTPRequestHandler, HTTPServer
import serverAct.webServerFn as coreLogicServer
import sys

webAddress=('127.0.0.1', 8082)
webHandle = HTTPServer(webAddress, coreLogicServer.httpRequestHandler)
print("Running server...." + str(webAddress))
print("Try urls like..." + str('http://localhost:8082/add/121/434'))
webHandle.serve_forever()