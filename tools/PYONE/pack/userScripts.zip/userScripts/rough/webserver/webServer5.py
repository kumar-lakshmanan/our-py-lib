'''
#For DevConsole
'''

from http.server import BaseHTTPRequestHandler, HTTPServer
import serverAct.webServerFn as coreLogicServer
import sys
import _thread

def myserver(arg1, arg2):
	webAddress=('127.0.0.1', 8082)
	webHandle = HTTPServer(webAddress, coreLogicServer.httpRequestHandler)
	print("Running server...." + str(webAddress))
	print("Try urls like..." + str('http://localhost:8082/add/121/434'))
	webHandle.serve_forever()

try:
   _thread.start_new_thread( myserver, ("Thread-1", 2, ) )
except:
   print ("Error: unable to start thread")