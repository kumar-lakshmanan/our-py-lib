'''
#For DevConsole
'''
import pyOneShortcuts

from http.server import BaseHTTPRequestHandler, HTTPServer
import serverAct.webServerFn as coreLogicServer
import sys
import select

from PyQt5.QtCore import QObject, QThread, pyqtSignal, pyqtSlot
from PyQt5.QtWidgets import QApplication, QWidget

import importlib 
importlib.reload(coreLogicServer)

class MyNewHTTPServer(HTTPServer):
	self._events = []
	self._stopped = False	

	def run(self):
		try:
			self.serve_forever()
		except Exception as e:
			print(crashSupport.errorReport())
		finally:
			self.server_close()
			print ('server closed')

	def get_request(self, time_func=time.time, select_func=select.select):
		print ('req arrived')
		return self.socket.accept()

	def _handle_request_noblock(self):
		"""Handle one request, without blocking.

		I assume that selector.select() has returned that the socket is
		readable before this function was called, so there should be no risk of
		blocking in get_request().
		"""
		try:
			print('handle no blocking')
			request, client_address = self.get_request()
			print(request)
		except Exception as e:
			return
			
		if self.verify_request(request, client_address):
			try:
				self.process_request(request, client_address)
			except:
				self.handle_error(request, client_address)
				self.shutdown_request(request)		
		
		
	def serve_forever(self, poll_interval=0.5):
		print('ServerStarterd!!!')
		
		try:
			while 1:
				print ('inside loop')
				self._handle_request_noblock()
				#self._handle_one_request()
				#QApplication.processEvents()
				print ('requst handle startted')
		finally:
			self.server_close()
			print ('OK BYE')

	def oneReqDone(self):
		#QApplication.processEvents()
		return 1

	def stop_serving_forever(self):
		"""Stop the serve_forever() loop.

		Stop happens on the next handle_request() loop; it will not stop
		immediately.  Since dev_appserver.py must run on py2.5 we can't
		use newer features of SocketServer (e.g. shutdown(), added in py2.6).
		"""
		self._stopped = True		

class HttpDaemon(QtCore.QThread):

	def run(self):
		print("Starting server....")
		self.webAddress=('127.0.0.1', 8082)
		print("Running server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))		
		self._server = MyNewHTTPServer(self.webAddress, coreLogicServer.httpRequestHandler)		
		self._server.run()
		QApplication.processEvents()

	def stop(self):
		self._server.shutdown()
		self._server.socket.close()
		self.wait()


dev.httpd = HttpDaemon()
dev.httpd.start()