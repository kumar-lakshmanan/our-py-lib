'''
#For DevConsole
'''
import pyOneShortcuts

from http.server import BaseHTTPRequestHandler, HTTPServer
import serverAct.webServerFn as coreLogicServer
import sys

from PyQt5.QtCore import QObject, QThread, pyqtSignal, pyqtSlot
from PyQt5.QtWidgets import QApplication, QWidget

import importlib 
importlib.reload(coreLogicServer)

class MyNewHTTPServer(HTTPServer):
	
	def run(self):
		try:
			self.serve_forever()
		except Exception as e:
			print(crashSupport.errorReport())
			raise
		finally:
			self.server_close()
	
	def serve_forever(self, poll_interval=0.5):
		print('ServerStarterd!!!')
		
		try:
			while self.oneReqDone():
				print ('inside loop')
				#self._handle_request_noblock()
				self._handle_one_request()
				print ('requst handle startted')
		finally:
			print ('OK BYE')

	def oneReqDone(self):
		#QApplication.processEvents()
		return 1
		

class HttpDaemon(QtCore.QThread):

	def run(self):
		print("Starting server....")
		self.webAddress=('127.0.0.1', 8082)
		print("Running server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))		
		self._server = MyNewHTTPServer(self.webAddress, coreLogicServer.httpRequestHandler)		
		self._server.run()
		QApplication.processEvents()

	def stop(self):
		self._server.shutdown()
		self._server.socket.close()
		self.wait()

dev.httpd = HttpDaemon()
dev.httpdshort = pyOneShortcuts.pyOneShortcutsCls(dev)
dev.httpdshortbtn = dev.httpdshort.doQuickShortcutWithIcon('StopServer', None, 'butterfly.png')
dev.httpdshortbtn.triggered.connect(dev.httpd.stop)
dev.httpd.start()