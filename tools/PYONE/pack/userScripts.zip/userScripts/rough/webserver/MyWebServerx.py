from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import MyWebServer
#For DevConsole

from PyQt5.QtCore import QObject, QThread, pyqtSignal, pyqtSlot
from PyQt5.QtWidgets import QApplication, QWidget

from http.server import BaseHTTPRequestHandler, HTTPServer
import serverAct.webServerFn as coreLogicServer

import importlib 
importlib.reload(coreLogicServer)

import sys
			
class CustomLog:
	def __init__(self, edit):
		self.edit = edit

	def write(self, data):
		#data = data.encode('string_escape').replace('\\','\\\\')
		data = data.replace("\\", "\\\\")
		self.edit.moveCursor(QtGui.QTextCursor.End)
		self.edit.insertPlainText(str(data))

class ServerCore(QtCore.QThread):
	
	def run(self):
		print("Starting server....")
		self.webAddress=('127.0.0.1', 8082)
		print("Running server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))		
		self._server = HTTPServer(self.webAddress, coreLogicServer.httpRequestHandler)		
		self._server.serve_forever()
		QApplication.processEvents()

	def stop(self):
		if(hasattr(self,'_server')):
			print('Shutting down server')
			try:
				self._server.shutdown()
				self._server.socket.close()	
			except Exception as e:
				print(crashSupport.errorReport())
		QApplication.processEvents()
		#self.wait()
		
class MyWebServerCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=MyWebServer.__file__.replace(".py",".ui")
		super(MyWebServerCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)

		self.oldStdOut = sys.stdout
		self.oldStdErr = sys.stderr
		
		#sys.stdout = OutLog( self.output, sys.stdout)
		#sys.stderr = OutLog( self.output, sys.stderr, QtGui.QColor(255,0,0) )		

		sys.stdout = CustomLog(self.output)
		sys.stderr = CustomLog(self.output)	
		
		self.startBt.clicked.connect(self.start)
		self.stopBt.clicked.connect(self.stop)
		self.server = ServerCore()

	def start(self):
		QApplication.processEvents()
		self.parent.setVisible(0)
		self.server.start()
		QApplication.processEvents()
		
	def stop(self):	
		self.server.stop()
		self.parent.setVisible(1)			
		QApplication.processEvents()
		print('Server Stopped!!!!')
	
	def reverStdIO(self):
		sys.stdout = self.oldStdOut
		sys.stderr = self.oldStdErr

	def closeEvent(self, event):
		QApplication.processEvents()
		print('Server Closed!!!!')	
		self.server.stop()		
		self.parent.setVisible(1)		
		QApplication.processEvents()
		event.accept()		
	
#	def __del__(self):
#		# Restore sys.stdout
#		sys.stdout = sys.__stdout__		

if (__name__=="__main__"):
	dev.MyWebServerClsObj = MyWebServerCls(dev)	
	dev.MyWebServerClsObj.show()