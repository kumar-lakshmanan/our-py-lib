'''
#For DevConsole
'''
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import threading
import pyOneShortcuts
import sip
import importlib 
import serverAct.webServerFn as coreLogicServer
from _ast import arg

class PyWebService(QtCore.QThread):
	
	def __init__(self, webAddress, logicModule):
		QtCore.QThread.__init__(self)
		self.webAddress = webAddress
		self.logicModule = logicModule
		self.webHandle = None

	def __del__(self):
		self.stopServer()		
		self.wait()

	def run(self):
		self.startServer()
		
	def quit(self):
		self.stopServer()
	
	def terminate(self):
		self.stopServer()
		
	def stopServer(self):
		print('Stopping server..!')
		self.webHandle.socket.close()
		del(self.webHandle)
		print('Stopped server!')
		
	def startServer(self):
		importlib.reload(coreLogicServer)
		print("Starting server....")
		self.webHandle=HTTPServer(self.webAddress, self.logicModule)
		print("Running server...." + str(self.webAddress))
		print("Try urls like..." + str('http://localhost:8082/add/121/434'))
		try:
			#sys.stderr = open('logfile.txt', 'w')
			#print(self.webHandle.log_message())
			self.webHandle.serve_forever()
		except:
			print ("Error: Server Crashed")


class SimpleWebServer():
	
	def __init__(self,parent):
		self.parent=parent
		self.webAddress=('127.0.0.1', 8082)
		self.server = PyWebService(self.webAddress, coreLogicServer.httpRequestHandler)

		self.pyshort = pyOneShortcuts.pyOneShortcutsCls(self.parent)
		self.stopper = self.pyshort.doQuickShortcutWithIcon('StopServer', None, 'butterfly.png')
		self.stopper.toggled.connect(self.stopServer)
		self.stopper.setCheckable(True)		
		
	def startServer(self):
		self.server.start()
	
	def stopServer(self):
		self.server.terminate()
		sip.delete(self.stopper)

dev.px = SimpleWebServer(dev)
dev.px.startServer()