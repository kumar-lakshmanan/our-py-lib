'''
#For DevConsole
'''
from suds.client import Client
from xmljson import BadgerFish  
from xml.etree.ElementTree import fromstring
from suds.sax.text import Raw
import json
from suds.transport.https import HttpAuthenticated
from suds.xsd.doctor import ImportDoctor, Import
from suds.client import Client
import urllib
import urllib3

from pysimplesoap.client import SoapClient

					
import base64

# code excluded for brevity

'''
base64string = base64.encodestring('%s:%s' % (username, password)).replace('\n', '')
authenticationHeader = {
    "SOAPAction" : "ActionName",
    "Authorization" : "Basic %s" % base64string
}
client = Client(url=wsdl_url, headers=authenticationHeader)
'''

url = 'http://www.webservicex.net/country.asmx?WSDL'

'''
clientx = SoapClient(wsdl=url,  trace=True)
r = clientx.GetCountryByCurrencyCode('USD')
print(r)
'''

import importlib
import types

import trek

dev.reloader(trek)

z = trek.trekCls()
z.runr()
