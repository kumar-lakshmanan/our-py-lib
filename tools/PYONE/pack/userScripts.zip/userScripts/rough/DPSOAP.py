'''
#For DevConsole
'''
from suds.client import Client
from xmljson import BadgerFish  
from xml.etree.ElementTree import fromstring
from suds.sax.text import Raw
import json
from suds.transport.https import HttpAuthenticated
from suds.xsd.doctor import ImportDoctor, Import
from suds.client import Client
from pysimplesoap.client import SoapClient
from pysimplesoap.simplexml import SimpleXMLElement

import base64
import os 
#os.environ["REQUESTS_CA_BUNDLE"] = os.path.join(os.getcwd(), "cacert.pem")
os.environ["HTTP_PROXY"]=os.environ["HTTPS_PROXY"]='http://aur\p729465:Feb4132%@10.7.33.71:8080'
# code excluded for brevity

import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context
	
	

from suds.client import Client
from suds.transport.https import HttpAuthenticated
from urllib.request import HTTPSHandler
import ssl

class CustomTransport(HttpAuthenticated):

    def u2handlers(self):

        # use handlers from superclass
        handlers = HttpAuthenticated.u2handlers(self)

        # create custom ssl context, e.g.:
        ctx = ssl.create_default_context(cafile=None)
        # configure context as needed...
        ctx.check_hostname = False

        # add a https handler using the custom context
        handlers.append(HTTPSHandler(context=ctx))
        return handlers


#base64string = base64.encodestring('%s:%s' % ('p729465d', 'Jan4132%')).replace('\n', '')
authenticationHeader = {
    "SOAPAction" : "",
    "Authorization" : "Basic cDcyOTQ2NWQ6SmFuNDEzMiU="
}


urls = 'http://www.webservicex.net/country.asmx?WSDL'
url = "https://10.40.253.13:5550/service/mgmt/amp/3.0"
#'Authorization':'Basic cDcyOTQ2NWQ6SmFuNDEzMiU='




#client = Client(url)
#client = Client(urls)
#print(client.service)
#result = client.service.GetCountryByCurrencyCode('USD')


'''
bf_str1 = BadgerFish()
rs = bf_str1.data(fromstring(result))

print(rs)
response = json.loads(json.dumps(rs))
print(response)
print('--')
print(response['NewDataSet']['Table'][0]['Name']['$'])
print(response['NewDataSet']['Table'][0]['Currency']['$'])
print(response['NewDataSet']['Table'][0]['CurrencyCode']['$'])
print(response['NewDataSet']['Table'][0]['CountryCode']['$'])
print('--')
'''