'''
#For DevConsole
'''

url = "https://10.40.253.13:5550/service/mgmt/amp/3.0"
ns = "http://www.datapower.com/schemas/appliance/management/3.0"

from pysimplesoap.client import SoapClient
from pysimplesoap.simplexml import SimpleXMLElement

import tempfile

import ssl 
from requests.utils import DEFAULT_CA_BUNDLE_PATH;
print(DEFAULT_CA_BUNDLE_PATH)
import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context
	
ssl._create_default_https_context = ssl._create_unverified_context
gc = ssl._create_unverified_context()
#gc = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
cacertTxt='C:\\Users\\p693490\\Desktop\\Testing\\Tools\\PyOne\\cacert.pem'
print(gc.load_default_certs())
print(gc.get_ca_certs())

	

client = SoapClient(location=url,namespace=ns,trace=True)
#client.http_headers = {'username' : 'p729465d','password':'Jan4132%'}
client.http_headers = {'Authorization':'Basic cDcyOTQ2NWQ6SmFuNDEzMiU='}
#client['Authorization'] = 'Basic cDcyOTQ2NWQ6SmFuNDEzMiU='
#x = client.GetDomainListRequest()


params = SimpleXMLElement("""<?xml version="1.0" encoding="UTF-8"?>
<GetDomainListRequest xmlns="http://www.datapower.com/schemas/appliance/management/3.0"/>
""", namespace=ns) # manually make request msg
response = client.call('GetDomainListRequest',params)

print('\n')
print(response.as_xml())
print('\n')
