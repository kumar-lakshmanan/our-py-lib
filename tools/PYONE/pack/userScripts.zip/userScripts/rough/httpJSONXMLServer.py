#For DevConsole
import sys, time
from http.server import HTTPServer, SimpleHTTPRequestHandler
from http.server import BaseHTTPRequestHandler, HTTPServer
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from urllib.parse import urlparse
import json
import importlib
import sys
import traceback

hostName = "127.0.0.1"
hostPort = 9000

def errorReport():
	# Show/Return Error Report
	traceback_lines = traceback.format_exc().split('\n')
	data = '\n'.join(traceback_lines)
	print(data)
	return data

def crashHandle():
	# Prepare Report
	data = errorReport()
	f = open('ServerCrashReport.txt', 'w')
	f.write(str(data))
	f.close()
	sys.exit(0)
	
class MyServer(SimpleHTTPRequestHandler):
	
	def do_POST(self):
		self.send_response(200)
		self.send_header("Content-type", "text/json")
		self.end_headers()
		try:
			self.response = {'SampleData':'Success'}
		except:
			self.response = errorReport()
			crashHandle()
		self.wfile.write(bytes(self.response ,'utf-8'))			
		
	def do_GET(self):
		self.send_response(200)
		self.send_header("Content-type", "text/json")
		self.end_headers()
		try:
			self.response = {'myresponse':'success'}
		except:
			self.response = errorReport()
			crashHandle()
		self.wfile.write(bytes(self.response ,'utf-8'))				

	def getURIInputs(self):
		query = urlparse(self.path).query
		query_components = dict(qc.split("=") for qc in query.split("&"))
		return query_components	
	
class HttpDaemon(QtCore.QThread):
	def run(self):
		self._server = HTTPServer((hostName, hostPort), MyServer)	   
		self._server.serve_forever()
	def stop(self):
		self._server.shutdown()
		self._server.socket.close()
		self.wait()
		
if __name__ == '__main__':
	dev.x = HttpDaemon()
	dev.x.start()
	print("Started HTTP Server")
	print("Try the url...")
	print(time.asctime(), "Server Starts - %s:%s" % (hostName, hostPort))   
	#ans = input()	 
	#x.stop()