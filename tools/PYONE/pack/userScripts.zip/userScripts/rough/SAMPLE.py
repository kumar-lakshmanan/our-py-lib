from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import SAMPLE
#For DevConsole
import http.server
import socketserver
import io


class Handler(http.server.SimpleHTTPRequestHandler):

    def do_GET(self):
        # Create an in-memory output file for the new workbook.
        output = io.BytesIO()

        # Even though the final file will be in memory the module uses temp
        # files during assembly for efficiency. To avoid this on servers that
        # don't allow temp files, for example the Google APP Engine, set the
        # 'in_memory' constructor option to True:
        print(output)


        # Rewind the buffer.
        output.seek(0)

        # Construct a server response.
        self.send_response(200)
        self.send_header('Content-Disposition', 'attachment; filename=test.xlsx')
        self.send_header('Content-type',
                         'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        self.end_headers()
        self.wfile.write(output.read())
        return


class SAMPLECls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=SAMPLE.__file__.replace(".py",".ui")
		super(SAMPLECls, self).__init__(self.parent)
		loadUi(self.uiFile, self)
		self.pushButton.clicked.connect(self.doRun)
		
	def initialize(self):
		self.parent.pylib.say("SAMPLEClsObj is working fine")

	def doRun(self):
		input = self.textEdit.toPlainText()
		self.label.setText(input)
		self.parent.pylib.say(input)

if (__name__=="__main__"):
	print('Server listening on port 8082...')
	#httpd = socketserver.TCPServer(('', 8082), Handler)
	#httpd.serve_forever()
	#print(dir(httpd))
	dev.SAMPLEClsObj = SAMPLECls(dev)
	dev.SAMPLEClsObj.show()
	dev.SAMPLEClsObj.raise_()