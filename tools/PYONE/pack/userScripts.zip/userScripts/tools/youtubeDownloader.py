from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import youtubeDownloader
import pyOneExternalProcess
import uiSettings
#For DevConsole

class youtubeDownloaderCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=youtubeDownloader.__file__.replace(".py",".ui")
		super(youtubeDownloaderCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)
		self.parent.startModuleReloading(uiSettings)

	def initialize(self):
		#UI Setting
		self.gridLayout.removeWidget(self.output)
		sip.delete(self.output)
		self.output = Qsci.QsciScintilla(self.centralwidget)
		self.output.setReadOnly(1)
		self.gridLayout.addWidget(self.output, 0, 0, 1, 0)
		self.gridLayout.update()		
		
		#Builds
		self.totalFlagItems = 15
		self.totalFlagPairs = []
		self.buildItems()
		
		for grpItem,txtItem in self.totalFlagPairs:
			self.connectFlags(grpItem,txtItem)
			
		#COnnections
		self.start.clicked.connect(self.doStart)
		self.stop.clicked.connect(self.doStop)

		#Connection LoadSave
		self.save.clicked.connect(self.doSave)
		self.load.clicked.connect(self.doLoad)

		self.save_2.clicked.connect(self.doSave)
		self.load_2.clicked.connect(self.doLoad)

		self.save_3.clicked.connect(self.doSave)
		self.load_3.clicked.connect(self.doLoad)

		self.save_4.clicked.connect(self.doSave)
		self.load_4.clicked.connect(self.doLoad)
		
		#Data Setting
		self.pyex = pyOneExternalProcess.pyOneExternalProcessCls(self.parent)
		self.pyex.processDisplay = self.doPrint
		self.pyex.processCompletedExternal = self.pyexStopped

		self.youtubeApp = self.parent.settings.youtubeApp
		self.workLoc = self.parent.settings.youtubeWorkLoc
		self.argFlags = {}		
	
		self.myStatusBar('Ready!')
	
		c = self.parent.ttls.fileContent(self.parent.scriptsDirName + '\\tools\\youtubeDownloader.txt')
		#print(c)
		
		self.splitter_2.setSizes([370, 190])
		self.splitter.setSizes([450, 260])

	def buildItems(self):
		self.flagGrpItems = []
		self.flagTxtItems = []
		self.totalFlagPairs = []
		self.flagGrpItems.append(self.flagItem)
		self.flagTxtItems.append(self.flagText)
		for cnt in range(2,self.totalFlagItems):
			grpItem = getattr(self,'flagItem_'+str(cnt))
			txtItem = getattr(self,'flagText_'+str(cnt))
			self.flagGrpItems.append(grpItem)
			self.flagTxtItems.append(txtItem)
			self.totalFlagPairs.append((grpItem,txtItem))
		
	def doSave(self):
		obj = self.parent.sender()
		objName = obj.objectName()
		_itm = objName.split("_")
		_id = '_' + _itm[1] if (len(_itm)==2) else ''
		saveFile = 'youtubeSettings'+_id
		
		uiItems = [	
					self.inputList,
					self.finalCommand
				   ]
		
		for grpItem,txtItem in self.totalFlagPairs:
			uiItems.append(grpItem)
			uiItems.append(txtItem)
		
		self.uiset = uiSettings.uiSettingsCls(saveFile, self.parent, self)
		self.uiset.save(uiItems)
	
	def doLoad(self):
		obj = self.parent.sender()
		objName = obj.objectName()
		_itm = objName.split("_")
		_id = '_' + _itm[1] if (len(_itm)==2) else ''
		loadFile = 'youtubeSettings'+_id
		
		self.uiset = uiSettings.uiSettingsCls(loadFile, self.parent, self)
		self.uiset.load()
		
		for grpItem,txtItem in self.totalFlagPairs:
			info = self.getItemInfo(grpItem)
			self.argFlags[info['flagGroupName']] = info['flagTextValue']
	
	def rebuildFlags(self):
		arg = ''
		for each in self.argFlags:
			val = self.argFlags[each]
			arg += val + '\n'
		lst = self.inputList.toPlainText()
		arg += lst + '\n'
		self.finalCommand.setText(arg)

	def updateFlagText(self):
		obj = self.parent.sender()
		info = self.getItemInfo(obj)
		self.argFlags[info['flagGroupName']] = info['flagTextValue']
		self.rebuildFlags()

	def addRemoveFlag(self):
		obj = self.parent.sender()
		info = self.getItemInfo(obj)

		if info['flagGroupName'] in self.argFlags.keys() and not info['flagGroupValue']:
			del self.argFlags[info['flagGroupName']]
		else:
			self.argFlags[info['flagGroupName']] = info['flagTextValue']
			
		self.rebuildFlags()

	def getItemInfo(self, obj):
		flagGroupName = ''
		flagGroupItem = ''
		flagGroupValue = ''
		flagTextName = ''
		flagTextItem = ''
		flagTextValue = ''

		if type(obj) == type(QtWidgets.QGroupBox()):
			flagGroupItem = obj
			flagGroupName = obj.objectName()
			flagGroupValue = obj.isChecked()
			
			_itm = flagGroupName.split("_")
			_id = '_' + _itm[1] if (len(_itm)==2) else ''
			
			flagTextName = 'flagText' + _id
			flagTextItem = getattr(self,flagTextName)
			flagTextValue = flagTextItem.text()
			
		if type(obj) == type(QtWidgets.QLineEdit()):			 
			flagTextItem = obj
			flagTextName = obj.objectName()
			flagTextValue = obj.text()

			_itm = flagTextName.split("_")
			_id = '_' + _itm[1] if (len(_itm)==2) else ''

			flagGroupName = 'flagItem' + _id
			flagGroupItem = getattr(self,flagGroupName) 
			flagGroupValue = flagGroupItem.isChecked()
				
		info = {}
		info['flagGroupName'] = flagGroupName
		info['flagGroupItem'] = flagGroupItem
		info['flagGroupValue'] = flagGroupValue
		info['flagTextName'] = flagTextName
		info['flagTextItem'] = flagTextItem
		info['flagTextValue'] = flagTextValue
		
		return info
						
	def connectFlags(self, flagItem, flagTextItem):
		flagItem.clicked.connect(self.addRemoveFlag)
		flagTextItem.textChanged.connect(self.updateFlagText)
		
	def pyexStopped(self, code):
		self.doPrint('\nCompleted with ' +str(code))
		self.start.setEnabled(0)
		self.stop.setEnabled(0)
		self.myStatusBar('Completed!')

	def doStart(self):
		self.args = str(self.finalCommand.toPlainText())
		
		self.pyex.setupExecution(self.youtubeApp,self.workLoc,self.args)
		self.pyex.executionDoStart()

		self.stop.setEnabled(1)
		self.start.setEnabled(0)
		self.myStatusBar('Running...')
		
	def doStop(self):
		print("Terminating execution...")
		self.pyex.executionDoTerminate()
		self.stop.setEnabled(0)
		self.start.setEnabled(0)
		self.myStatusBar('Terminated')
	
	def doPrint(self,content):
		self.output.setCursorPosition(self.output.lines(),0)
		self.output.insert(str(content))
		vsb = self.output.verticalScrollBar()
		vsb.setValue(vsb.maximum())    
		hsb = self.output.horizontalScrollBar()
		hsb.setValue(0)   
		
	def closeEvent(self, event):
		self.doStop()
		event.accept()
	
	def myStatusBar(self, txt):
		self.statusBar.showMessage(txt)
		self.parent.pylib.say(txt)

if (__name__=="__main__"):
	dev.youtubeDownloaderClsObj = youtubeDownloaderCls(dev)
	dev.youtubeDownloaderClsObj.initialize()
	dev.youtubeDownloaderClsObj.show()
	dev.youtubeDownloaderClsObj.raise_()
	
	
