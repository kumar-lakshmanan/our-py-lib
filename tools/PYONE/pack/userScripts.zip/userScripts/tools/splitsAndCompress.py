#For DevConsole

from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import splitsAndCompress
import splitAndJoin
import os,sys

class SplitsAndCompressCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent  
		self.settings=self.parent.settings
		self.uiFile=splitsAndCompress.__file__.replace(".py",".ui")
		super(SplitsAndCompressCls, self).__init__(self.parent)		
		loadUi(self.uiFile, self)
	
		self.pushButton.clicked.connect(self.doCompress)
		self.pushButton_2.clicked.connect(self.doExtract)
		self.pushButton_3.clicked.connect(self.doSplit)
		self.pushButton_4.clicked.connect(self.doJoin)

		self.splitAndJoinObj = splitAndJoin.splitAndJoinCls(self.parent)
		
	def showEvent(self, *arg):		
		#Compresss
		workDir = os.path.dirname(self.parent.scriptsDirName)
		workDir = os.path.join(workDir,'temp')
		
		path1 = self.parent.scriptsDirName
		path2 = os.path.join(workDir,'splitJoin','Packed.tar.gz')
		
		#Extract
		path3 = path2
		path4 = os.path.join(workDir,'splitJoin','Extracted')
		
		#Split
		path5 = path2
		path6 = os.path.join(workDir,'splitJoin','Splitted')
		
		#Join
		path7 = path6
		path8 =  os.path.join(workDir,'splitJoin','Joined','Packed.tar.gz') 

		self.lineEdit.setText(path1)
		self.lineEdit_2.setText(path2)

		self.lineEdit_3.setText(path3)
		self.lineEdit_4.setText(path4)

		self.lineEdit_5.setText(path5)
		self.lineEdit_6.setText(path6)

		self.lineEdit_7.setText(path7)
		self.lineEdit_8.setText(path8)		

		
	def doExtract(self):
		source = self.lineEdit_3.text()
		destination = self.lineEdit_4.text()
		self.splitAndJoinObj.extract(source,destination)		

	def doCompress(self):
		source = self.lineEdit.text()
		destination = self.lineEdit_2.text()
		dpath = os.path.dirname(destination)
		if not os.path.exists(dpath): 
			os.makedirs(dpath)				   
		self.splitAndJoinObj.compress(source,destination)

	def doJoin(self):
		source = self.lineEdit_7.text()
		destination = self.lineEdit_8.text()
		dpath = os.path.dirname(destination)
		if not os.path.exists(dpath): 
			os.makedirs(dpath)		 
		self.splitAndJoinObj.join(source,destination)

	def doSplit(self):
		source = self.lineEdit_5.text()
		destination = self.lineEdit_6.text()
		if not os.path.exists(destination): 
			os.makedirs(destination)		   
		self.splitAndJoinObj.split(source,destination)
		
if (__name__=="__main__"):

	if(not hasattr(dev,'SplitsAndCompressClsObj')  or dev.devMode):	   
		dev.SplitsAndCompressClsObj = SplitsAndCompressCls(dev)
		
	dev.SplitsAndCompressClsObj.show()
	dev.SplitsAndCompressClsObj.raise_()