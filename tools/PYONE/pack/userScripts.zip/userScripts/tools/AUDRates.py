'''
#For DevConsole
'''
from bs4 import BeautifulSoup
import json
import mysqlite

class AudratesCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.settings=self.parent.settings
		self.m=mysqlite.SqliteCls(self.parent)
		print("AudratesCls is ready!")

	def doThisActivity(self):
		#self.updateHistory()
		#self.rateFor(400)
		#print(self.getHistory(1))
		print("Ready to do this activity")   

	def showRates(self):
		iciciRate=self.iciciExchangeRate()
		#rafflesRate=self.rafflesExchangeRate()
		orbitRate=self.orbitExchangeRate()
		currentRate=self.currentExchangeRate()
		print("Current Exchange Rate: " + str(currentRate))
		#print("Exchange Rate Raffles: " + str(rafflesRate))
		print("Exchange Rate Orbit: " + str(orbitRate))
		print("Exchange Rate ICICI: " + str(iciciRate)) 
		return orbitRate
		
	def showRatesFor(self, amount=1): 
		iciciRate=self.iciciExchangeRate()
		rafflesRate=self.rafflesExchangeRate()
		orbitRate=self.orbitExchangeRate()
		currentRate=self.currentExchangeRate()

		xr = float(rafflesRate)
		xo = float(orbitRate)
		xi = float(iciciRate)
		cr = float(currentRate)

		raffles = (amount * xr) - (6 * xr)
		orbit = (amount * xo) - (4 * xo)
		icici =  (amount * xi) - (50)

		print("Current Exchange Rate: " + str(currentRate))
		print("Exchange Rate Raffles: " + str(xr))
		print("Exchange Rate Orbit: " + str(xo))
		print("Exchange Rate ICICI: " + str(xi))	
		print('\n')
		print("For " + str(amount) + " AUD Raffles: " + str(raffles))
		print("For " + str(amount) + " AUD Orbit: " + str(orbit))
		print("For " + str(amount) + " AUD ICICI: " + str(icici))	
				 
	def _updateFileCore(self, rafs,orb,ici,cr):
		f = open(self.settings.exchangeRateFile,"a")
		nw = self.parent.ttls.getDateTime()
		data = '"{0}","{1}","{2}","{3}","{4}"\n'.format(nw,rafs,orb,ici,cr)
		f.write(data)		
		f.close()

	def updateHistory(self):
		xe = self.currentExchangeRate()
		orbit = self.orbitExchangeRate()
		raffles = self.rafflesExchangeRate()
		icici = self.iciciExchangeRate()
		self._updateFileCore(raffles,orbit,icici,xe)
		
		nw = self.parent.ttls.getDateTime()
		self.m.doInsert('xrate',(str(nw),xe,orbit,icici,raffles))		
		print("Exchange Rate Updated!")
		
	def showHistory(self):	
		f = open(self.settings.exchangeRateFile,"r")
		lines = f.readlines()
		for eachLine in lines:
			print(eachLine)
		f.close()
	
	def getHistory(self, columnNo):
		res = []
		f = open(self.settings.exchangeRateFile,"r")
		lines = f.readlines()
		for eachLine in lines:
			lst = eachLine.split(",")
			itm = lst[columnNo].replace("\"","").strip()
			res.append(itm)
		return res		

	def currentExchangeRate(self):
		url = 'http://www.xe.com/currencyconverter/convert/?Amount=1&From=AUD&To=INR'
		data = self.parent.pyOneGeneralClsObj.readUrl(url)

		bs = BeautifulSoup(data,"html.parser")
		level1 = bs.findAll('td',{"class":"rightCol"})
		for each in level1:
			if(each.find('span',{"class":"uccResCde"})):
				return each.contents[0].strip()
				
	def orbitExchangeRate(self):
		url = 'https://secure.orbitremit.com/api/rates/AUD:INR.json'
		data = self.parent.pyOneGeneralClsObj.readUrl(url)
		
		orbitSoup = BeautifulSoup(data,"html.parser")
		orbitVal = json.loads(orbitSoup.contents[0])
		orbitRate = orbitVal['exchangeRate']['Rate']['exchangeRate']
		return orbitRate	   
		
	def rafflesExchangeRate(self):
		url = 'https://rafflesforex.com.au/'
		data = self.parent.pyOneGeneralClsObj.readUrl(url)
		
		raffleSoup = BeautifulSoup(data,"html.parser")
		rafflesfinding = raffleSoup.findAll('h4',style='margin: 10px 0')
		rafflesRate = rafflesfinding[0].contents[0].split("=")[1].strip()
		return rafflesRate

	def iciciExchangeRate(self):	
		url = 'http://www.icicibank.com/nri-banking/money_transfer/money-transfer-rates.page'
		data = self.parent.pyOneGeneralClsObj.readUrl(url)
		
		iciciSoup = BeautifulSoup(data,"html.parser")
		
		l1 = iciciSoup.find_all('div',class_="main-contentz")[0]
		#print(iciciSoup.encode('ascii','ignore').decode('utf-8'))
		for each in l1.tbody:
			nxt = each.next_sibling
			if nxt and str(nxt.next_element.next.extract()).strip()=='Australia':
				return str(nxt.td.find_all_next()[0].contents[0].encode('ascii','ignore').decode('utf-8'))	

if __name__ == '__main__':
	dev.AudratesClsObj = AudratesCls(dev)
	dev.AudratesClsObj.showRates()
	#dev.AudratesClsObj.updateHistory()
	#dev.AudratesClsObj.showRatesFor(700)
