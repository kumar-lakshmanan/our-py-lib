from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import quickTools
#For DevConsole
import inspect
import importlib
import sip
import os

class QuickToolsCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent	 
		self.settings=self.parent.settings		  
		self.uiFile=quickTools.__file__.replace(".py",".ui")
		super(QuickToolsCls, self).__init__(self.parent)		
		loadUi(self.uiFile, self)
		self.existingObj=[]
		self.popsUIObjects()
		self.updateMenu()
		
	def quickListDblClicked(self, item):
		selectedItem = self.parent.sender()
		itemName = selectedItem.text()
		info = ''
		
		if '--' in itemName:
			info = 'Just a seperator'
			
		elif(itemName == 'OpenFolder - Scripts'):
			info = self.parent.scriptsDirName
			self.parent.pylib.launchUrl(info)

		elif(itemName == 'OpenFolder - App'):
			info = os.getcwd()
			self.parent.pylib.launchUrl(info)

		elif(itemName == 'Clean Output Window'):
			info = ''
			self.parent.outputWindow.textEdit.setText(info)
		
		elif(itemName == 'Toggle Work Area'):
			info = not self.parent.mdiArea.isVisible()
			self.parent.mdiArea.setVisible(info)
			
		elif(itemName == 'DateStamp'):
			info = self.parent.pyOneGeneralClsObj.getDateStamp()
			info = 'Copied: ' + info

		elif(itemName == 'DateTimeStamp'):
			info = self.parent.pyOneGeneralClsObj.getDateTimeStamp()
			info = 'Copied: ' + info
		
		
		
		
		
		
		
		
		
		
		
		self.parent.pylib.trayMessage('Quick - ' + str(itemName) + ' - ' + str(info))
		
#--------------------------------------------------------------------------------------------------------------------
	def updateMenu(self):
		#Update QuickTools list

		self.parent.updateTrayMenu('|')			
		for n in range(0,self.list1.count()):
			itemName = self.list1.item(n).text()
			if '--' in itemName:
				self.parent.updateTrayMenu('|')
			else:
				self.parent.updateTrayMenu(itemName,self.quickListDblClicked)
		self.parent.updateTrayMenu('|')			
			
	def parentName(self, object):
		for each in self.parent.__dict__:
			if self.parent.__dict__[each] == object:
				return str(each)

	def deleteAll(self):
		winObjs = self.parent.findChildren(QtWidgets.QMainWindow)
		for eachWinObj in winObjs:
			objName = self.parentName(eachWinObj)
			if(objName):
				clsObj = eachWinObj.__class__
				clsName = eachWinObj.__class__.__name__
				modObj = clsObj.__module__ 
				if (str(modObj) != '__main__'):
					m = __import__(modObj)
					importlib.reload(m)
					newCls = getattr(m,clsName)
					eachWinObj.deleteLater()
					sip.delete(eachWinObj)			 
					delattr(self.parent,objName)
					newObj = newCls(self.parent)
					setattr(self.parent,objName,newObj)
			
	def popsUIObjects(self):
		self.existingObj=[]
		self.listWidget.clear()
		lst = self.parent.children()
		rlst = lst[::-1]
		for each in rlst:
			lst = inspect.getmro(type(each))
			if(type(QtWidgets.QMainWindow()) in lst):
				if(type(each).__name__ in self.existingObj):
					each.deleteLater()
				else:
					self._addItem(self.listWidget, type(each).__name__, each)
					self.existingObj.append(type(each).__name__)
				
	def listItemDblClicked(self, itm):
		if(itm and itm.data(36)):
			obj = itm.data(36)
			if(obj):
				print(obj)
				obj = obj.__class__(self.parent)
				obj.show()
				obj.raise_()				
		
	def _addItem(self, listWidget, label, data):
		itm = QtWidgets.QListWidgetItem(str(label))
		itm.setData(36, data)
		self.listWidget.addItem(itm)					
								 
if (__name__=="__main__"):
	if(not hasattr(dev,'QuickToolsClsObj') or sip.isdeleted(dev.QuickToolsClsObj) or dev.devMode):	   
		   dev.QuickToolsClsObj = QuickToolsCls(dev)
	dev.QuickToolsClsObj.show()
	dev.QuickToolsClsObj.raise_()