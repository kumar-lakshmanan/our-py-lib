'''
#For DevConsole
'''
from esb import datapower
dev.startModuleReloading(datapower)

dp = datapower.somaHandler()


f = open('temp/res.xml','r')
z = f.read()
z = str(z).replace('\n','')
z = str(z).replace('\\n','')
f.close()
v = dp.dp.xml2Json(str(z))
env = v['{http://schemas.xmlsoap.org/soap/envelope/}Envelope']
body = env['{http://schemas.xmlsoap.org/soap/envelope/}Body']
response = body['{http://www.datapower.com/schemas/management}response']
dateTime = response['{http://www.datapower.com/schemas/management}timestamp']['$']
filestore = response['{http://www.datapower.com/schemas/management}filestore']
loc = filestore['location']

res = dp.reqRes.getDirTree(loc)
dp.dp.prittyPrintJSON(res)
print(res)

f = open('temp/newjson.json','w')
f.write(str(res))
f.close()
