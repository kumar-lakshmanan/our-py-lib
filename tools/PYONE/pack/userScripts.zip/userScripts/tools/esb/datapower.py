'''
#For DevConsole
'''

from esb import soma
from esb import somaReqRes

import base64

class somaHandler():
	
	def __init__(self, loginId=None, password=None, somaServiceUrl=None, trace=0):
		self.somaServiceUrl = somaServiceUrl if somaServiceUrl else dev.decrypt(dev.settings.somaServiceUrl)
		self.loginId = loginId if loginId else dev.decrypt(dev.settings.somaLoginUID)
		self.password = password if password else dev.decrypt(dev.settings.somaPassword)
		self.dp = soma.core(self.loginId,self.password,self.somaServiceUrl,trace)
		self.reqRes = somaReqRes.core(trace)
		self.trace=trace
		
	def tracer(self, matter):
		if(self.trace):
			print('log_somaHandler: ' + str(matter))

	def getFileStore(self, domain):
		body = self.reqRes.getFileStore()
		body = body.replace('[domain]',domain)
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))
		return resp		
		
	def createFolder(self, domain, path):
		body = self.reqRes.createFolder()
		body = body.replace('[domain]',domain)
		body = body.replace('[path]',path)
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))
		return self.reqRes.okStatusParse(resp)		
		
	def getFile(self, domain, srcFile, dstFolder=None):
		body = self.reqRes.getFile(domain,srcFile)
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))
		status = self.reqRes.storeFile(resp,dstFolder)
		return 'Success' if status else 'Fail'

	def getFileContent(self, domain, srcFile):
		body = self.reqRes.getFile(domain,srcFile)
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))
		return self.reqRes.getFileContentInAscii(resp)
		
	def uploadFile(self, domain, srcFile, dstFile):
		body = self.reqRes.uploadFile()
		body = body.replace('[domain]',domain)
		body = body.replace('[dstFile]',dstFile)
		f = open(srcFile,'r')
		b64str = base64.encodestring(f.read().encode('ascii'))
		f.close()
		body = body.replace('[fileContent]',b64str.decode('ascii'))
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))
		return self.reqRes.okStatusParse(resp)
	
	def writeFileContent(self, domain, dstFile, txtContent):
		body = self.reqRes.uploadFile()
		body = body.replace('[domain]',domain)
		body = body.replace('[dstFile]',dstFile)
		b64str = base64.encodestring(txtContent.encode('ascii'))
		body = body.replace('[fileContent]',b64str.decode('ascii'))
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))
		return self.reqRes.okStatusParse(resp)
	
	def flushCache(self, domain, xmlManager):
		body = self.reqRes.flushCache()
		body = body.replace('[domain]',domain)
		body = body.replace('[xmlManager]',xmlManager)	
		self.tracer('Calling DP....')
		resp = self.dp.callService(body)
		self.tracer('DP Call Status - ' + str(self.dp.response))	
		return self.reqRes.okStatusParse(resp)