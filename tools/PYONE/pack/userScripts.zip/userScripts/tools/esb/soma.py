'''
#For DevConsole
'''

import xmljson
import json
import base64
import requests
import logging
from xml.etree.ElementTree import fromstring
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

import somaReqRes

'''
logging.basicConfig()
logging.getLogger().setLevel(logging.DEBUG)
requests_log = logging.getLogger("requests.packages.urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.propagate = True
'''

class core():
	
	def __init__(self, loginId=None, password=None, somaServiceUrl=None, trace=0):
		self.somaServiceUrl = somaServiceUrl if somaServiceUrl else dev.decrypt(dev.settings.somaServiceUrl)
		self.loginId = loginId if loginId else dev.decrypt(dev.settings.somaLoginUID)
		self.password = password if password else dev.decrypt(dev.settings.somaPassword)
		self.response = None
		self.trace=trace
		
	def getAuthCode(self, username, password):
		ids = username + ':' + password		
		return ''.join(['Basic ',base64.b64encode(ids.encode('ascii')).decode('ascii')])

	def xml2Json(self, xml):
		bf = xmljson.BadgerFish()
		rs = bf.data(fromstring(xml))
		response = json.loads(json.dumps(rs))
		return response			

	def prittyPrintJSON(self, jsonStr):
		print (json.dumps(jsonStr, sort_keys=True, indent=2, separators=(',', ': ')))
		
	def callService(self, message):
		headers = {}
		headers['SOAPAction']=''
		headers['User-Agent']='Mozilla/5.0'
		headers['Content-Type']='text/xml; charset=UTF-8'
		headers['Authorization']=self.getAuthCode(self.loginId,self.password)		
		self.response = requests.post(self.somaServiceUrl,data=message,headers=headers,verify=False)
		self.tracer('DP Request Header - '+ str(self.response.request.headers))
		self.tracer('DP Response Header - '+ str(self.response.headers))
		self.tracer('DP Request Payload - ' + str(self.response.request.body))
		return self.response.content		

	def tracer(self, matter):
		if(self.trace):
			print('log_somaCore: ' + str(matter))
