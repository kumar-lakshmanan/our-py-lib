'''
#For DevConsole
'''
import soma
import base64
import os

class core():
	
	def __init__(self, trace=0):
		self.trace = trace
		
	def tracer(self, matter):
		if(self.trace):
			print('log_somaReqResCore: ' + str(matter))
			
	def getFileStore(self):
		return '''<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <SOAP-ENV:Body>
  <request
   domain="[domain]"
    xmlns="http://www.datapower.com/schemas/management">
   <get-filestore location="local:"/>
  </request>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
'''

	def createFolder(self):
		return '''<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <SOAP-ENV:Body>
  <request
   domain="[domain]"
     xmlns="http://www.datapower.com/schemas/management">
   <do-action>
    <CreateDir xmlns="">
     <Dir>[path]</Dir>
    </CreateDir>
   </do-action>
  </request>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
'''

	def getFile(self, domain, dpFile):
		return """<?xml version="1.0" encoding="UTF-8"?>
	<SOAP-ENV:Envelope
	 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
	 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
	   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	 <SOAP-ENV:Body>
	  <request
	   domain="[domain]"
		xmlns="http://www.datapower.com/schemas/management">
	   <get-file name="[dpFile]"/>
	  </request>
	 </SOAP-ENV:Body>
	</SOAP-ENV:Envelope>
	""".replace("[domain]",domain).replace("[dpFile]",dpFile)

	def storeFile(self, respXml, storeLoc=''):
		dp = soma.core()
		jsnRsp = dp.xml2Json(respXml.decode('ascii'))
		env = jsnRsp['{http://schemas.xmlsoap.org/soap/envelope/}Envelope']
		body = env['{http://schemas.xmlsoap.org/soap/envelope/}Body']
		response = body['{http://www.datapower.com/schemas/management}response']
		fileNode = response['{http://www.datapower.com/schemas/management}file']
		fileContent = fileNode['$']
		fileName = fileNode['@name']
		txtContent = base64.b64decode(fileContent.encode('ascii'))
		fileNameAlone = os.path.basename(fileName)		
		newFileName = os.path.join(storeLoc,fileNameAlone) if storeLoc else fileNameAlone
		f = open(newFileName,'w')
		f.write(txtContent.decode('ascii'))
		f.close()	
		self.tracer(newFileName + ' created!')
		print(newFileName + ' created!')
		return 1
		
	def getFileContentInAscii(self, respXml):
		dp = soma.core()
		jsnRsp = dp.xml2Json(respXml.decode('ascii'))
		env = jsnRsp['{http://schemas.xmlsoap.org/soap/envelope/}Envelope']
		body = env['{http://schemas.xmlsoap.org/soap/envelope/}Body']
		response = body['{http://www.datapower.com/schemas/management}response']
		fileNode = response['{http://www.datapower.com/schemas/management}file']
		fileContent = fileNode['$']
		txtContent = base64.b64decode(fileContent.encode('ascii'))
		return txtContent
		
	def uploadFile(self):
		return '''<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <SOAP-ENV:Body>
  <request
   domain="[domain]"
    xmlns="http://www.datapower.com/schemas/management">
   <set-file name="[dstFile]">[fileContent]</set-file>
  </request>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

	def okStatusParse(self, respXml):
		dp = soma.core()
		jsnRsp = dp.xml2Json(respXml.decode('ascii'))
		env = jsnRsp['{http://schemas.xmlsoap.org/soap/envelope/}Envelope']
		self.tracer(env)
		body = env['{http://schemas.xmlsoap.org/soap/envelope/}Body']
		response = body['{http://www.datapower.com/schemas/management}response']
		dateTime = response['{http://www.datapower.com/schemas/management}timestamp']['$']
		result = response['{http://www.datapower.com/schemas/management}result']['$']
		self.tracer(dateTime)
		self.tracer(result)
		return result

	def fileStoreParse(self, respXml):
		dp = soma.core()
		jsnRsp = dp.xml2Json(respXml.decode('ascii'))
		env = jsnRsp['{http://schemas.xmlsoap.org/soap/envelope/}Envelope']
		self.tracer(env)
		body = env['{http://schemas.xmlsoap.org/soap/envelope/}Body']
		response = body['{http://www.datapower.com/schemas/management}response']
		dateTime = response['{http://www.datapower.com/schemas/management}timestamp']['$']
		filestore = response['{http://www.datapower.com/schemas/management}filestore']
		loc = filestore['location']
		return loc

	def getDirTree(self, currentNode, parentName='local:/', path='local:/'):
	
		fileList = []
		dirList = []
		files = []
		dirs = []	
		temp = {}	
		
		if('file' in currentNode.keys()):
			fileList = currentNode['file']
			if(fileList.__class__ == [].__class__ and len(fileList)):
				for eachFile in fileList:
					fileName = eachFile['@name']
					filePath = path					
					files.append({'name':fileName,'location':filePath})

			if(fileList.__class__ == {}.__class__):
				singleFile = fileList
				fileName = singleFile['@name']
				filePath = path					
				files.append({'name':fileName,'location':filePath})
			
		if('directory' in currentNode.keys()):
			dirList = currentNode['directory']
			if (dirList.__class__ == [].__class__ and len(dirList)):
				for eachDir in dirList:
					dirName = self._dirNameAlone(eachDir['@name'])
					dirLoc = eachDir['@name']
					dirs.append(self.getDirTree(eachDir, dirName, dirLoc))
					
			if (dirList.__class__ == {}.__class__):
				singleDir = dirList
				if singleDir.__class__ == {}.__class__:				
					dirName = self._dirNameAlone(singleDir['@name'])
					dirLoc = singleDir['@name']
					dirs.append(self.getDirTree(singleDir, dirName, dirLoc))

		temp[parentName] = {}		
		temp[parentName]['name'] = parentName
		temp[parentName]['location'] = path
		temp[parentName]['files'] = files			
		temp[parentName]['directory'] = dirs
				
		return temp
		
	def _dirNameAlone(self, path):
		return os.path.basename(path)

	def flushCache(self):
		return '''<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope
 xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <SOAP-ENV:Body>
  <request
   domain="[domain]"
     xmlns="http://www.datapower.com/schemas/management">
   <do-action>
    <FlushStylesheetCache xmlns="">
     <XMLManager>[xmlManager]</XMLManager>
    </FlushStylesheetCache>
   </do-action>
  </request>
 </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
'''		