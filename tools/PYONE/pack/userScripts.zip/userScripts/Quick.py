'''
#For DevConsole
'''
import threading
import time
import sqlite3
import pyOneExternalProcess

#Clean Window
#dev.outputWindow.textEdit.setMarginWidth(1, 4)
#dev.outputWindow.textEdit.clear()

print(dev.scriptsDirName)



class tests():
	
	def __init__(self):
		print(dev.settings.youtubeWorkLoc)
		
		
tests()		
