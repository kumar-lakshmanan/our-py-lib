'''
#For DevConsole
#Kumaresan
'''

from PyQt5 import QtCore, QtGui, QtWidgets

import sip

class pyOneShortcutsCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.settings=self.parent.settings		
		self.shortcutPair = {}
		self.parent.pylib.say("pyOneShortcutsCls is ready!")
		
	def initialize(self):
		self.parent.newToolBar = QtWidgets.QToolBar('Custom Tools',self.parent) 
		self.parent.addToolBar(self.parent.newToolBar)
		self.parent.updateTrayMenu('|')

		# CHeck this url for icon names:
		# http://dev.vizuina.com/farmfresh/ 
		
		self.createObjBrowser()
		self.createQuickTools()
		self.createDevMode()

		self.parent.pylib.say("pyOneShortcutsCls initialized!")
	
	def createDevMode(self):
		self.devToggle = self.doQuickShortcutWithIcon('toggleDevMode', None, 'bios.png')
		self.devToggle.toggled.connect(self.startToggleDevMode)
		self.devToggle.setCheckable(True)
		
	def createObjBrowser(self):
		import objBrowser
		if(not hasattr(self.parent,'objBrowserClsObj')):		
			self.parent.objBrowserClsObj = objBrowser.objBrowserCls(self.parent)
		self.doQuickShortcutWithIcon('ObjBrowser', self.startObjBrowser, 'attributes_display.png')	

	def createQuickTools(self):
		import quickTools	
		if(not hasattr(self.parent,'QuickToolsCls')):					
			self.parent.QuickToolsClsObj = quickTools.QuickToolsCls(self.parent)
			self.doQuickShortcutWithIcon('QuickTools', self.startQuickTools, 'breeze.png')	
		
	def startObjBrowser(self):
		self.parent.objBrowserClsObj.show()
		self.parent.objBrowserClsObj.raise_()

	def startQuickTools(self):
		self.parent.QuickToolsClsObj.show()
		self.parent.QuickToolsClsObj.raise_()
		
	def startToggleDevMode(self, state):
		self.parent.devMode = state
		self.parent.pylib.say('Developer mode state: ' + str(state))
				
	def doQuickShortcut(self, label, callBackFn, type_=1):
		if(type_==1):
			return self._doShortcut(label, 'bullet_star.png', callBackFn, self.parent.newToolBar)   
		elif(type_==2):
			return self._doShortcut(label, 'bullet_red.png', callBackFn, self.parent.newToolBar)			   
		elif(type_==3):
			return self._doShortcut(label, 'bullet_purple.png', callBackFn, self.parent.newToolBar)			   
		elif(type_==4):
			return self._doShortcut(label, 'bullet_pink.png', callBackFn, self.parent.newToolBar)
			
	def doQuickShortcutWithIcon(self, label, callBackFn, icon):
		return self._doShortcut(label, icon, callBackFn, self.parent.newToolBar)
		
	def _doShortcut(self, label='text', icon='bullet_star.png', callBackFn=None, toolBar=None):
		if (label=='|'):
			self.parent.addSeparator()
			self.parent.updateTrayMenu('|')
		else:
			action = QtWidgets.QAction(self.parent)
			action.setText(label)
			if callBackFn is not None: action.triggered.connect(callBackFn)
			self.parent.qtIcon.setIcon(action, icon)
			toolBar.addAction(action)
			
			if callBackFn is not None:
				self.shortcutPair[label]=callBackFn
				self.parent.updateTrayMenu(label,self._actionContextItemClicked)	
			return action		
			
	def _actionContextItemClicked(self, *arg):
		obj = self.parent.sender()
		caller = str(obj.text())
		print("Call from " + caller)
		callBackFn = self.shortcutPair[caller]
		if(callBackFn):
			callBackFn()		
			
if __name__ == '__main__':
	dev.customShotcutsClsObj = pyOneShortcutsCls(dev)
	dev.quickToolShortcut()
	#dev.customShotcutsClsObj.initializeRequiredObjects()
