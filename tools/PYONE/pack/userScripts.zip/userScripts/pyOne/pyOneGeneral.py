'''
#For DevConsole
'''
#For DevConsole
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
import requests
import urllib.request as req
from urllib.request import Request
from bs4 import BeautifulSoup
import json
import os
import socket
import pyOneStartups
import pyOneExternalProcess

os.environ["REQUESTS_CA_BUNDLE"] = os.path.join(os.getcwd(), "cacert.pem")

class pyOneGeneralCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.parent.pylib=self
		self.isInternetAvailable=False		
		print("pyOneGeneralCls is ready!")

	def initialize(self):
		#self.checkInternetAvailability()
		if (socket.gethostname()=='NIGSA718029'):
			self.parent.pyDesigner = 'C:\\Users\\p693490\\Desktop\\Testing\\Tools\\PyQt5\\designer.exe'
			#os.environ["HTTP_PROXY"]=os.environ["HTTPS_PROXY"]=self.settings.nabProxy
		if (socket.gethostname()=='MUKUND-PC'):
			self.parent.pyDesigner = "C:\Python34\Lib\site-packages\PyQt5\designer.exe"
		
		self.parent.pylib.say("pyOneGeneralCls initialized")

	def checkInternetAvailability(self):
		self.parent.pylib.say("Checking internet availability....")
		url='https://secure.orbitremit.com/'
		try:
			self.parent.pylib.say("Trying..." + url)
			data=self.readUrl(url)
			if(data):
				self.isInternetAvailable=True
				self.parent.pylib.say("Internet available!")
				return
		except:
			pass
		self.parent.pylib.say("Internet not available!")

	def readUrl(self,url):
		if socket.gethostname()=='NIGSA291604':
			return self.readUrlOffice(url)
		else:
			return self.readUrlHome(url)

	def readUrlOffice(self, url):
		os.environ["HTTP_PROXY"]=os.environ["HTTPS_PROXY"]=self.nabProxy
		proxy = req.ProxyHandler({'http': os.environ["HTTP_PROXY"],'https': os.environ["HTTPS_PROXY"]})
		hdr = {'User-Agent':'Mozilla/5.0'}
		auth = req.HTTPBasicAuthHandler()
		opener = req.build_opener(proxy, auth, req.HTTPHandler)
		req.install_opener(opener)

		reqst = Request(url, headers=hdr)
		webContent = req.urlopen(reqst).read()
		return webContent

	def readUrlHome(self, url):
		webContent = requests.get(url,verify=True).text
		return webContent
				
	def trayMessage(self, message):
		self.parent.traymessage("PyOne",str(message))
		self.say("Tray: " + str(message))
		
	def say(self, info, tray=0):
		print("PyOne: "+str(info))
		self.parent.traymessage("PyOne",str(info))
	
	def launchUrl(self,url):
		cmd = 'explorer.exe %s' % url
		self.parent.pyOneExternalProcessClsObj = pyOneExternalProcess.pyOneExternalProcessCls(self.parent)
		self.parent.pyOneExternalProcessClsObj.setupExecution('explorer.exe', None, url)
		self.parent.pyOneExternalProcessClsObj.executionDoStart()

	def shallIStop(self,tag):
		res = self.parent.ttls.isPathOK(tag) and int(self.parent.ttls.fileContent(tag))
		print('Check ' + str(tag) + ' for terminating the execution ... ' + str(bool(res)))
		return bool(res)

	def getDateStamp(self):
		str = self.parent.ttls.getDateTime('%Y%m%d')
		cb = QtWidgets.QApplication.clipboard()
		cb.clear(mode=cb.Clipboard )
		cb.setText(str, mode=cb.Clipboard)				
		self.parent.pylib.say('Copied: ' + str)
		return str
		
	def getDateTimeStamp(self):
		str = self.parent.ttls.getDateTime('%Y%m%d%H%M%S')
		cb = QtWidgets.QApplication.clipboard()
		cb.clear(mode=cb.Clipboard )
		cb.setText(str, mode=cb.Clipboard)
		self.parent.pylib.say('Copied: ' + str)
		return str
		
if __name__ == '__main__':
	dev.pyOneGeneralClsObj = pyOneGeneralCls(dev)
	dev.pyOneGeneralClsObj.getDateStamp()
