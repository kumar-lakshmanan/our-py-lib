'''
#For DevConsole
'''
import os
from PyQt5 import QtCore, QtWidgets
import crashSupport
import sip

class pyOneExternalProcessCls():
	
	def __init__(self,parent):
		self.parent=parent
		#self.txt = QTextStream()
		#self.txt.show()
		self.qprocess=QtCore.QProcess()
		self.qprocessEnv=QtCore.QProcessEnvironment.systemEnvironment()

		self.qprocess.started.connect(self.processStarted)   		
		self.qprocess.readyReadStandardOutput.connect(self.processOutput)
		self.qprocess.readyReadStandardError.connect(self.processErrorOutput)
		self.qprocess.finished.connect(self.processCompleted) # gives args
		self.qprocess.error.connect(self.processErrorOccurred)  # gives args		
		#self.qprocess.errorOccurred.connect(self.processErrorOccurred)
		self.qprocess.stateChanged.connect(self.processChanged)  # gives args		

		self.processDisplay(self.parent.ttls.getCurrentPath())
		self.parent.pylib.say("pyOneExternalProcessCls is ready!")		
					
	def initialize(self):
		self.parent.pylib.say('pyOneExternalProcessCls Initialized.')
	
	def setupExecution(self, application, workingDir='', args='', envVariableTupleList=[]):
		self.application=application
		self.workingDir=workingDir
		self.args=args
		for eachEnv in envVariableTupleList:
			if(len(eachEnv)==2):
				self.qprocessEnv.insert(eachEnv[0],eachEnv[1])

		self.qprocess.setProgram(self.application)
		self.qprocess.setArguments([self.args])
		self.qprocess.setWorkingDirectory(self.workingDir)
		self.qprocess.setProcessEnvironment(self.qprocessEnv)	

	def executionDoStart(self):
		if self.qprocess.state() != QtCore.QProcess.Running:
			command = str(self.application +  ' ' + self.args)
			self.processDisplay('\nExecution starting...')
			self.processDisplay('\nCommand: ')
			self.processDisplay('\n'+command)
			self.processDisplay('\nWorking Dir: ' + str(self.workingDir))
			#print('Custom Env: ' + ';'.join(self.parent.qprocessEnv.toStringList()))
			self.qprocess.setProcessChannelMode(QtCore.QProcess.SeparateChannels)
			#self.qprocess.setProcessChannelMode(QtCore.QProcess.ForwardedChannels)
			self.qprocess.setOpenMode(QtCore.QIODevice.Text)
			self.qprocess.start(command)
			if not self.qprocess.waitForStarted():
				self.processErrorOutput()
				self.processDisplay('\nUnable to start the process')

	def executionDoTerminate(self):
		if (not sip.isdeleted(self.qprocess)):		
			if self.qprocess.state() == QtCore.QProcess.Running:	
				self.processDisplay('\nExecution terminating...')			
				self.qprocess.kill()
				sip.delete(self.qprocess)
				self.processDisplay('\nExecution Terminated!')	

	def executionShowStatus(self):
		print(self._procesStatus(self.qprocess.state()))

	def processStarted(self):
		self.processDisplay('\n--processStarted--')

	def processOutput(self):
		if (not sip.isdeleted(self.qprocess)):
			if self.qprocess.canReadLine():
				QtWidgets.QApplication.processEvents()
				self.processDisplay(str(self.qprocess.readAllStandardOutput().data().decode("utf-8")).replace('\r\n',''))			
				if self.parent.pylib.shallIStop('externalprocess.txt'): self.executionDoTerminate()
			
	def processErrorOutput(self):
		QtWidgets.QApplication.processEvents()
		#print('Err:'+str(self.qprocess.errorString()))
		if (not sip.isdeleted(self.qprocess)):
			data = str(self.qprocess.readAllStandardError().data().decode("utf-8")).replace('\r\n','')
			if data: self.processDisplay('\nError: '+data)

	def processCompleted(self, exitCode, processStatus):
		if processStatus==0:
			self.processDisplay('\n--ProcessCompleted-ExitCode:--' + str(exitCode))
			self.processCompletedExternal(str(exitCode))
		if processStatus==1:
			self.processErrorOutput()
			self.processDisplay('\n--ProcessCrashCompleted-ExitCode:--' + str(exitCode))
			self.processCompletedExternal(str(exitCode))

	def processErrorOccurred(self, errorCode):
		self.processErrorOutput()
		if(errorCode==0):
			self.processDisplay("\nProcess Error Occurred: FailedToStart")
		elif(errorCode==1):
			self.processDisplay("\nProcess Error Occurred: Crashed")
		elif(errorCode==2):
			print("\nProcess Error Occurred: Timedout")
		elif(errorCode==3):
			self.processDisplay("\nProcess Error Occurred: ReadError")
		elif(errorCode==4):
			self.processDisplay("\nProcess Error Occurred: WriteError")
		elif(errorCode==5):
			self.processDisplay("\nProcess Error Occurred: UnknownError")
		
	def processChanged(self, status):
		self.processDisplay(self._procesStatus(status))

	def processCompletedExternal(self, code):
		print('Completed: ' + code)
		
	def _procesStatus(self, status):
		if status == QtCore.QProcess.Running:
			return "\nProcess Status: Running"
		elif status == QtCore.QProcess.Starting:
			return "\nProcess Status: Starting"
		elif status == QtCore.QProcess.NotRunning:
			self.processErrorOutput()
			return "\nProcess Status: NotRunning (Could be completed/Crashed/Stopped/Not yet Started)"
			
	def processDisplay(self, content):
		print(content)

if __name__ == '__main__':
	dev.pyOneExternalProcessClsObj = pyOneExternalProcessCls(dev)

	application = 'E:\\YoutubeDownloader\\bin\\youtube-dl.exe'
	workingDir = "E:\\YoutubeDownloader\\bin"

	url = 'https://www.youtube.com/watch?v=c3kvCQj41wk'
	name = 'Test'
	dest = r'D:\Youtubes\Out'	
		
	args = ''
	
	args += '--output "{0}\\{1}.%(ext)s"'.format(dest,name)
	args += ' --recode-video {0}'.format('mp4')
	args += ' -k'
		
	args += ' {0}'.format(url)	
	
	dev.pyOneExternalProcessClsObj.setupExecution(application,workingDir,args)
	dev.pyOneExternalProcessClsObj.executionDoStart()
