'''
#For DevConsole
'''
import os

class pyOneRunPerDayCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.parent.pylib.say("RunperdayCls is ready!")
					
	def initialize(self):
		self.parent.pylib.say('RunOnce Initialized')

	def forgetTodaysRun(self):
		self.parent.ttls.writeFileContent('today','')
		self.parent.pylib.say("Forgot todays run!")		

if __name__ == '__main__':
	dev.RunperdayClsObj = RunperdayCls(dev)
	dev.RunperdayClsObj.doRun(doThisOnce)
	#dev.RunperdayClsObj.forgetTodaysRun()
