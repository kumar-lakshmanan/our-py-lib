'''
#For DevConsole
'''
import os
from PyQt5.QtCore import QSettings
import inspect

class pyOneSettingsCls():
	
	def __init__(self, parent):		
		self.parent = parent
		self.mySettings =  QSettings('settings.ini',QSettings.IniFormat)		
		
		self.desktopPath = 'C:\\Users\\npn\\Desktop\\devCons'
		self.devConsDB = 'devSystem.db'		
		
		self.splitJoinReadSize = 1024
		self.splitJoinChunkSize = 1
		self.splitJoinPartName = 'Part'	
		
		self.youtubeApp = 'E:\\YoutubeDownloader\\bin\\youtube-dl.exe'
		self.youtubeWorkLoc = 'E:\\YoutubeDownloader\\bin'	
		
		self.somaServiceUrl = 'o{{wzA66875;759<:58:A<<<76zly}pjl6tnt{6977;' 
		self.somaLoginUID = 'w>9@;=<k'
		self.somaPassword = 'Qhu;8:9,'	
		
		
	def readSettings(self):
		lst = self.getVariables()
		for eachItem in lst:
			var = eachItem[0]
			val = eachItem[1]
			newVal = self.mySettings.value(var,getattr(self,var))
			setattr(self,var,newVal)
		
	def writeSettings(self):
		lst = self.getVariables()
		for eachItem in lst:
			var = eachItem[0]
			self.mySettings.setValue(var, getattr(self,var))

	def getVariables(self):
		itms = []
		lst = inspect.getmembers(self)
		for eachMember in lst:
			var = eachMember[0]					
			val = eachMember[1]
			if (type(val) is type(1) or
				type(val) is type('') or
				type(val) is type([]) or
				type(val) is type(()) or
				type(val) is type({})
				):
				if (not str(var) in ['__dict__','__module__']):
					itms.append((var,val))		
		return itms
		
	def initialize(self):   
		print("Initializing settings....")
		self.readSettings()

if '__main__' == __name__:
	dev.pyOneSettingsClsObj = pyOneSettingsCls(dev)	
	dev.pyOneSettingsClsObj.readSettings()
	dev.pyOneSettingsClsObj.writeSettings()
	
