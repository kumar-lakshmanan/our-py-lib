'''
#For DevConsole
'''
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets

class pyOneTimerCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.parent.pylib.say("pyOneTimerCls is ready!")
		self.fnTimerDone = {}
		
	def initialize(self):
		self.parent.qtime=QtCore.QTimer(self.parent)
		self.parent.qtime.timeout.connect(self.timeoutAction)   		
		self.parent.pylib.say("pyOneTimerCls Initialized")

	def addTimerExecFunctions(self, fn, argList = ()):
		self.fnTimerDone[fn.__name__]=(fn,argList)

	def startTimer(self,secs=5):
		self.parent.pylib.say("-Timer Started-")
		self.parent.qtime.start(1000 * secs)
		
	def stopTimer(self):
		self.parent.pylib.say("-Timer Stopped-")
		self.parent.qtime.stop()
	
	def timeoutAction(self):
		self.parent.pylib.say("---Timer Timed out--")
		for eachFn in self.fnTimerDone:
			fns = self.fnTimerDone[eachFn]
			fnObj = fns[0]
			args = fns[1]
			fnObj(args)
		

if __name__ == '__main__':
	dev.pyOneTimerClsObj = pyOneTimerCls(dev)
