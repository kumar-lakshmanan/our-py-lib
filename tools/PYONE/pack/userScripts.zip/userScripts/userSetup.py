'''
#For DevConsole
'''

import os
import socket
import sys
import crashSupport
import pyOneStartups
import version
import commandLineHandler

'''
Order of PyOne Calls

AutoExecute:
	pyOneStartups
		pyOneSettings		For all settings value
		pyOneGeneral		General Functions - trayMessage, timeStamp, requestUrl,
		pyOneRunPerDay		Run some thing only once per day
		pyOneTimer			Repeat execution on time interval
		pyOneShortcuts		UI Alter and Shortcuts toolbars

IndependentExecute:
		pyOneExternalProcess		External process call

'''

try:

	print("-----Commandline Check-----")
	cmd = commandLineHandler.cmdHandler(dev)
	if cmd.isCmdLine(): cmd.executeCmdLine()
	
	print("-----Auto started-----")	
	dev.pyOneStartupsClsObj=pyOneStartups.pyOneStartupsCls(dev)
	dev.pyOneStartupsClsObj.initialize()	

	dev.devMode=0
	justfy=25
	print('Version History')
	print('-------')
	if(hasattr(version,'__buildHistory__')):
		print(version.__buildHistory__.replace('<br>','\n'))
	print('-------')
	print("Dev mode".ljust(justfy,'.') + str(dev.devMode))
	print("Style list".ljust(justfy,'.') + str(dev.qtTools.getStyleList()))
	print("Applying style".ljust(justfy,'.') + "Windows")
	print("Hostname".ljust(justfy,'.') + socket.gethostname())
	print("Timestamp".ljust(justfy,'.') + dev.ttls.getDateTime())
	print("Working Dir".ljust(justfy,'.') + os.getcwd())
	print("PyDesigner".ljust(justfy,'.') + dev.pyDesigner)
	print("Scripting Dir".ljust(justfy,'.') + dev.scriptsDirName)		
	print("Sample Decryption".ljust(justfy,'.') + dev.decrypt('Ylhk!'))
	print("-----End-----")
	
	dev.showNormal()
	dev.showMinimized()
	
	dev.pylib.say("PyOne is ready for use!",1)

except Exception as e:
	print(crashSupport.errorReport())
	print("------Startup Error! Please, Investigate!----------")	
	raise