from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import HTTPBasedFileServer
from http.server import HTTPServer, SimpleHTTPRequestHandler
#For DevConsole
HOST, PORT = '127.0.0.1', 12345

class HttpDaemon(QtCore.QThread):
	
	def run(self):
		self._server = HTTPServer((HOST, PORT), SimpleHTTPRequestHandler)
		self._server.serve_forever()

	def stop(self):
		self._server.socket.close()
		QApplication.processEvents()	
		self._server.server_close()	
		QApplication.processEvents()		
		self._server.shutdown_request(self._server.socket)
		QApplication.processEvents()		
		del(self._server)
		QApplication.processEvents()		
		#self._server.shutdown()		
		#self.wait()
		QApplication.processEvents()		
		
class HTTPBasedFileServerCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=HTTPBasedFileServer.__file__.replace(".py",".ui")
		super(HTTPBasedFileServerCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)
		
		self.btnStart.clicked.connect(self.doStartServer)
		self.btnStop.clicked.connect(self.doStopServer)
		
	def initialize(self):
		self.server = HttpDaemon()
		self._print("Started HTTP Server")
		self._print("Try the url...")
		self._print("http://%s:%s"%(HOST,PORT))		
		self._print("HTTPBasedFileServerClsObj is working fine")

	def doStartServer(self):
		self.parent.setVisible(0)
		self.server.start()
		self._print('Server Started!')

	def doStopServer(self):
		self.parent.setVisible(1)
		self.server.stop()
		self._print('Server Stopped!')
	
	def _print(self,info=''):
		QApplication.processEvents()
		data = self.dispInfo.toPlainText()
		info = data + '\n' + info
		self.dispInfo.setText(info)
		self.parent.pylib.say(info)	
		QApplication.processEvents()	

if (__name__=="__main__"):
	if(not hasattr(dev,'HTTPBasedFileServerClsObj') or sip.isdeleted(dev.HTTPBasedFileServerClsObj) or dev.devMode):
		dev.HTTPBasedFileServerClsObj = HTTPBasedFileServerCls(dev)
		dev.HTTPBasedFileServerClsObj.initialize()
	dev.HTTPBasedFileServerClsObj.show()
	dev.HTTPBasedFileServerClsObj.raise_()