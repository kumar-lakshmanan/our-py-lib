'''
#For DevConsole
'''
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets

class CustomLog:
	def __init__(self, textEditor):
		#QTextEdit
		self.edit = textEditor
	
	def write(self, data):
		data = data.replace("\\", "\\\\")
		self.edit.moveCursor(QtGui.QTextCursor.End)
		self.edit.insertPlainText(str(data))
		vsb = self.edit.verticalScrollBar()
		vsb.setValue(vsb.maximum())    
		hsb = self.edit.horizontalScrollBar()
		hsb.setValue(0)  
		

