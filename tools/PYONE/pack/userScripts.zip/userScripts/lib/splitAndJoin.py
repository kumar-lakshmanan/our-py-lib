'''
#For DevConsole
'''
import tarfile
import os
import sys

kilobytes = 1024
megabytes = kilobytes * 1000

class splitAndJoinCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.settings=self.parent.settings
		self.readSize=self.settings.splitJoinReadSize
		self.chunkSize=self.settings.splitJoinChunkSize
		self.chunkSize=int(self.chunkSize * megabytes)
		print("splitAndJoinCls is ready!")

	def compress(self, sourceFolder, destination='compressed.tar.gz'):
		destinationFolder = os.path.dirname(destination)
		if not os.path.exists(destinationFolder):		  # caller handles errors
			os.mkdir(destinationFolder)				# make dir, read/write parts				
		tar = tarfile.open(destination, "w")
		baseName = os.path.basename(sourceFolder)
		tar.add(sourceFolder,arcname=baseName,recursive=True)		
		tar.close()	
		print("Source: " + sourceFolder)
		print("Destination: " + destination)
		print("Base: " + baseName)
		print("Compressed!\n")

	def extract(self, sourceFile='compressed.tar.gz', destination=''):
		if not os.path.exists(destination):		  # caller handles errors
			os.mkdir(destination)				# make dir, read/write parts		
		tar = tarfile.open(sourceFile, "r")
		tar.extractall(destination)
		tar.close()
		print("Source: " + sourceFile)
		print("Destination: " + destination)
		print("Extracted!\n")		
		
	def split(self, fromfile, todir): 
		if not os.path.exists(todir):		  # caller handles errors
			os.mkdir(todir)				# make dir, read/write parts
		else:
			for fname in os.listdir(todir):		# delete any existing files
				os.remove(os.path.join(todir, fname)) 
		partnum = 0
		input = open(fromfile, 'rb')		   # use binary mode on Windows
		while 1:					   # eof=empty string from read
			chunk = input.read(self.chunkSize)		  # get next part <= chunksize
			if not chunk: break
			partnum  = partnum+1
			filename = os.path.join(todir, (self.settings.splitJoinPartName + '%04d' % partnum))
			fileobj  = open(filename, 'wb')
			fileobj.write(chunk)
			fileobj.close()				# or simply open(  ).write(  )
		input.close(  )
		assert partnum <= 9999			 # join sort fails if 5 digits
		return partnum
		print("Source: " + fromfile)
		print("Destination: " + todir)
		print("Split!\n")   
		
	def join(self, fromdir, tofile):
		output = open(tofile, 'wb')
		parts  = os.listdir(fromdir)
		parts.sort()
		for filename in parts:
			filepath = os.path.join(fromdir, filename)
			fileobj  = open(filepath, 'rb')
			while 1:
				filebytes = fileobj.read(self.readSize)
				if not filebytes: break
				output.write(filebytes)
			fileobj.close(  )
		output.close(  )
		print("Source: " + fromdir)
		print("Destination: " + tofile)
		print("Joined!\n")   
		
if __name__ == '__main__':
	dev.splitAndJoinClsObj = splitAndJoinCls(dev)
	codeLocation='J:\our-py-lib\CommonLib\src\kmxPyQt\devConsole3\DevConsolePlug_BIN\Scripts'
	zipLocation='J:\our-py-lib\CommonLib\src\kmxPyQt\devConsole3\DevConsolePlug_BIN\CompressTest\Scripts.tar.gz'
	newCodeLocation='J:\our-py-lib\CommonLib\src\kmxPyQt\devConsole3\DevConsolePlug_BIN\CompressTest'
	splitLoc='J:\our-py-lib\CommonLib\src\kmxPyQt\devConsole3\DevConsolePlug_BIN\CompressTest\Splits'
	joinLoc='J:\our-py-lib\CommonLib\src\kmxPyQt\devConsole3\DevConsolePlug_BIN\CompressTest\Splits\Joined'
	dev.splitAndJoinClsObj.compress(codeLocation,zipLocation)
	dev.splitAndJoinClsObj.extract(zipLocation,newCodeLocation)
	dev.splitAndJoinClsObj.split(zipLocation,splitLoc)
	dev.splitAndJoinClsObj.join(splitLoc,joinLoc)
