'''
#For DevConsole
'''

from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import pickle

class uiSettingsCls():
	
	def __init__(self, settingsFile, parent, uiClass):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.settingsFile = settingsFile
		self.uiClass = uiClass

	def save(self, uiItems=[]):
		saveData = {}
		for each in uiItems:
			name,value = self.getNameAndValue(each)
			saveData[name] = value			
		pickle.dump( saveData, open( self.settingsFile, "wb" ) )
			
	def load(self):
		saveData = pickle.load( open( self.settingsFile, "rb" ) )	
		
		for each in saveData.keys():
			itemName = each
			itemValue = saveData[each]
			self.setNameAndValue(itemName,itemValue)
	
	def getNameAndValue(self, obj):
		name = value = ''
		name = obj.objectName()
		
		if type(obj) == type(QtWidgets.QGroupBox()):
			value = obj.isChecked()	
		elif type(obj) == type(QtWidgets.QLineEdit()):
			value = obj.text()				
		elif type(obj) == type(QtWidgets.QTextEdit()):
			value = obj.toPlainText()	
		else:
			print('Unknown type: ' + str(obj.__class__))		
			print('Properties ' + str(dir(obj)))
			
		return (name,value)
		
	def setNameAndValue(self, name, value):
		obj = getattr(self.uiClass,name)
		
		if type(obj) == type(QtWidgets.QGroupBox()):
			obj.setChecked(value)
		elif type(obj) == type(QtWidgets.QLineEdit()):
			obj.setText(value)
		elif type(obj) == type(QtWidgets.QTextEdit()):
			obj.setText(value)
		else:
			print('Unknown type: ' + str(obj.__class__))		
			print('Properties ' + str(dir(obj)))	
		