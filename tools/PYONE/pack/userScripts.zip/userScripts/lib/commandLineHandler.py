'''
#For DevConsole
'''
import sys
import os
import crashSupport
import time 

class cmdHandler():
	
	def __init__(self,parent):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.argsList = sys.argv

	def isCmdLine(self):		
		return 1 if self.isCmdPresent('cmd') else print('Not a commandline')
		
	def isCmdPresent(self, cmd):
		for eachItem in self.argsList:
			if cmd in eachItem:
				return 1
		return 0
		
	def getModule(self):
		for eachItem in self.argsList:
				if 'cmd' in eachItem:
					return eachItem.split('=')[1]
	def getModArgs(self):
		index = 0
		newArgs = []
		for eachItem in self.argsList:
				if 'cmd' in eachItem:
					index = self.argsList.index(eachItem)
		if(index>1):
			for i in range(index+1,len(self.argsList)):
				newArgs.append(self.argsList[i]) 				
		return newArgs
		
	def executeCmdLine(self):
		print(self.argsList)
		modStr = self.getModule()
		mod = __import__(modStr)
		mod.doRun(self.parent, self.getModArgs())
		self.inform(modStr + ' execution completed')
		self.closeApplication()
		
	def inform(self, matter, sec=4):
		self.parent.traymessage('PyOne',matter)
		time.sleep(4)
		
	def closeApplication(self):
		self.parent.traykiller()
		self.parent.sessionClosed()
		os._exit(0)
		