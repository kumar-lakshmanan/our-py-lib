from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import dpFileBrowser
import xml.dom.minidom
from esb import datapower

#For DevConsole

if (__name__=="__main__"):
	hostUrl = dev.decrypt(dev.settings.somaServiceUrl)
	uid = dev.decrypt(dev.settings.somaLoginUID)
	password = dev.decrypt(dev.settings.somaPassword)
	domain = 'TEST1'	
	trace = 0

class dpFileBrowserCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent,uid,password,domain,hostUrl,trace=0):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=dpFileBrowser.__file__.replace(".py",".ui")
		super(dpFileBrowserCls, self).__init__(self.parent)
		self.parent.startModuleReloading(datapower)
		loadUi(self.uiFile, self)

		self.uid = uid
		self.password = password
		self.domain = domain
		self.hostUrl = hostUrl
		self.trace = trace
		
		self.treeData = {}
		
	def loadDatapower(self):
		self.dp = datapower.somaHandler(self.uid,self.password,self.hostUrl,self.trace)		
		
	def initialize(self):		
		self.lineEdit.setText('')
		self.setCB()
		
		#Qsci can't be done at design time. Add it dynamically
		self.addDynamicUIs()
		
		#Editor UI Update
		self.refineEditorUI()
		
		#loadDatapower
		self.loadDatapower()
		
		#connections
		self.uiConnections()

		#Auto Triggers
		self.btnRefreshTreeClicked()
		
	def uiConnections(self):
		self.treeWidget.itemDoubleClicked.connect(self.treeClicked)
		self.btnRefreshTree.clicked.connect(self.btnRefreshTreeClicked)
		self.btnSaveFile.clicked.connect(self.btnSaveFileClicked)
		self.cbDomain.currentTextChanged.connect(self.cbDomainChanged)
	
	def setCB(self):
		index = self.cbDomain.findText(self.domain, QtCore.Qt.MatchFixedString)
		if index >= 0:
			self.cbDomain.setCurrentIndex(index)
		
	def cbDomainChanged(self, newDomain):
		self.treeWidget.clear()
		self.treeData = {}
		self.domain = newDomain
		self.btnRefreshTreeClicked()
	
	def btnSaveFileClicked(self):
		fileName = self.lineEdit.text()
		fileContent = self.editor.text()
		if(fileContent and fileName):
			print('Saving file....' + fileName)
			resXml = self.dp.writeFileContent(self.domain, fileName, fileContent)
			self.parent.pylib.say(fileName + ' saved!')		
			print(resXml)
		
	def btnRefreshTreeClicked(self):
		print ('Loading ... ' + self.domain)
		self.setWindowTitle(self.domain + ' - DP File Browser / Editor')
		resxml = self.dp.getFileStore(self.domain)
		fileDirNodeJson = self.dp.reqRes.fileStoreParse(resxml)
		customDirTreeJson = self.dp.reqRes.getDirTree(fileDirNodeJson)
		self.loadTree(customDirTreeJson)
		self.parent.pylib.say(self.domain + ' tree loaded!')
		
	def treeClicked(self, item):
		name = item.text(0)
		loc = getattr(item, 'dx1')
		node = getattr(item, 'dx2')
		typ = getattr(item, 'dx3')
		
		if(self.trace):
			print('-Type:' + typ)
			print('-Loc: ' + loc)
			print('-Node: '  + str(node))
		
		if(typ=='directory'):
			self.populateDirOnClick(item, node)
		if(typ=='files'):
			self.loadFile(item, node)
	
	def loadFile(self, item, node):
		loc = node['location']
		fileName = node['name']
		fileFullName = loc + '/' + fileName
		print('Loading... ' + fileFullName)
		self.lineEdit.setText(fileFullName)
		content = self.dp.getFileContent(self.domain, fileFullName)
		self.editor.setText(content.decode('ascii'))
		self.updateEditor(fileFullName)
		self.parent.pylib.say(fileName + ' loaded!')		
	
	def updateEditor(self, fileFullName):
		typ = self._getFileType(fileFullName)
		if(typ == 'js'):
			self.nowParser = Qsci.QsciLexerJavaScript()
		elif(typ in ['xsd','wsdl','xml','xsl']):
			self.nowParser = Qsci.QsciLexerXML()
		else:
			self.nowParser = Qsci.QsciLexerCPP()
		self.editor.setLexer(self.nowParser)
			
	def populateDirOnClick(self, item, node):
		dirs = []
		files = []
		item.takeChildren()
		
		if 'directory' in node.keys():
			dirs = node['directory']
			
		if 'files' in node.keys():			
			files = node['files']
		
		for eachDir in dirs:
			for eachDirKey, eachDirNode in eachDir.items():
				dirName = eachDirNode['name']
				dirLoc = eachDirNode['location']
				dirType = 'folder'
				self._treeAddChild(dirType, item, dirName, dirLoc, eachDirNode,'directory')

		for eachFile in files:
			fileName = eachFile['name']
			fileLoc = eachFile['location']
			fileType = self._getFileType(fileName)
			self._treeAddChild(fileType, item, fileName, fileLoc, eachFile,'files')		
			
	def loadTree(self, treeNode):
		dirs = []
		files = []
		self.treeData = {}
		self.treeData = treeNode
		self.treeWidget.clear()
		
		if 'local:/' in self.treeData.keys():
			dirs = self.treeData['local:/']['directory']
			files = self.treeData['local:/']['files']
		
		for eachDir in dirs:
			for eachDirKey, eachDirNode in eachDir.items():
				dirName = eachDirNode['name']
				dirLoc = eachDirNode['location']
				self._treeAddRoots('folder',dirName,dirLoc,eachDirNode,'directory')

		for eachFile in files:
			fileName = eachFile['name']
			fileLoc = eachFile['location']
			fileType = self._getFileType(fileName)
			self._treeAddRoots(fileType,fileName,fileLoc,eachFile,'files')

	def _getFileType(self, fileName):
		ext = os.path.splitext(fileName)[1]
		ext = ext.replace('.','')
		return ext.lower()
		
	def _treeAddRoots(self, typ, txt, hiddenTxt='', hiddenItem=None, hiddentItem2=None):
		self.tempItem = QtWidgets.QTreeWidgetItem()
		self.tempItem.setText(0, txt)
		self._setIcon(self.tempItem,typ)
		setattr(self.tempItem, 'dx1', hiddenTxt)		
		setattr(self.tempItem, 'dx2', hiddenItem)		
		setattr(self.tempItem, 'dx3', hiddentItem2)
		return self.treeWidget.addTopLevelItem(self.tempItem)		

	def _treeAddChild(self, typ, parentItem, txt, hiddenTxt='',hiddenItem=None, hiddentItem2=None):
		self.tempItem = QtWidgets.QTreeWidgetItem()
		self.tempItem.setText(0, txt)
		self._setIcon(self.tempItem,typ)
		setattr(self.tempItem, 'dx1', hiddenTxt)
		setattr(self.tempItem, 'dx2', hiddenItem)
		setattr(self.tempItem, 'dx3', hiddentItem2)
		return parentItem.addChild(self.tempItem)			

	def _setIcon(self, item, typ='folder/xml/xsl/xsd/wsdl/js'):		
		if(typ=='folder'):
			self._iconCore(item, 'folder.png')
		if(typ=='xml'):
			self._iconCore(item, 'file_extension_divx.png')
		if(typ=='js'):
			self._iconCore(item, 'code.png')		
		if(typ=='wsdl'):
			self._iconCore(item, 'file_extension_m4p.png')					
		if(typ=='xsd'):
			self._iconCore(item, 'file_extension_xpi.png')					
		if(typ=='xsl'):
			self._iconCore(item, 'file_extension_xls.png')
			
	def _iconCore(self, item, iconName):
		icon = QtGui.QIcon()
		pixMap = QtGui.QPixmap(':/fatcow/32x32/'+iconName)
		s = QtCore.QSize(16, 16) 
		pixMap.scaled(s)        
		icon.addPixmap(pixMap, QtGui.QIcon.Normal, QtGui.QIcon.Off)
		item.setIcon(0,icon)			
		
	def refineEditorUI(self):
		font = QtGui.QFont()
		font.setFamily('Courier')
		font.setFixedPitch(True)
		font.setPointSize(10)
		self.editor.setFont(font)
		self.editor.setMarginsFont(font)

		self.editor.setMarginSensitivity(1, True)
		self.editor.setAutoCompletionSource(Qsci.QsciScintilla.AcsAll)
		self.editor.setAutoCompletionThreshold(1)
		self.editor.setAutoIndent(True)
		self.editor.setIndentationsUseTabs(True)
		self.editor.setTabWidth(3)
		self.editor.setMarginLineNumbers(1, 1)
		self.editor.setMarginWidth(1, 40)        
		self.editor.setBraceMatching(Qsci.QsciScintilla.StrictBraceMatch)
		self.editor.setUtf8(True)
		self.editor.setEolVisibility(False)      
		self.editor.setCaretLineVisible(True)
		self.editor.setCaretLineBackgroundColor(QColor("#ffe4e4"))	
		self.nowParser = Qsci.QsciLexerXML()
		self.editor.setLexer(self.nowParser)
		self.editor.setFolding(1,2)
				
	def addDynamicUIs(self):
		#Temp add some widget to the layout and check the grid name and grid row col number and then remove tht widget from UI and create them dynamically here
		self.editor = Qsci.QsciScintilla(self)
		self.editor.setObjectName("editor")
		self.gridLayout_4.addWidget(self.editor, 2, 0, 1, 0)
	

if (__name__=="__main__"):
	dev.dpFileBrowserClsObj = dpFileBrowserCls(dev,uid,password,domain,hostUrl,trace)
	dev.dpFileBrowserClsObj.initialize()
	dev.dpFileBrowserClsObj.show()
	dev.dpFileBrowserClsObj.raise_()
	