'''
#For DevConsole
'''

import pyOneShortcuts
import pyOneTimer

#dev.startModuleReloading(pyOneTimer)

#Vars
myVar = 'Hello'

#SampleTimeFn
def timerFn(args=[]):
	cTime = dev.ttls.getDateTime()
	info = 'Now the time is : ' + cTime + ' args ' + str(args)
	print(info)
	return info

#### Adding a Toolbar Shortcut #####
sh = pyOneShortcuts.pyOneShortcutsCls(dev)
sh.doQuickShortcut('myNewFn', timerFn, 4)

