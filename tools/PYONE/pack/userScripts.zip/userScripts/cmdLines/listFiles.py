'''
#For DevConsole
'''
import sys

class listFilesCls():
	
	def __init__(self,parent,args):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		print('OK LOADED')
		print(args)
		
	def initialize(self):
		print('OK INITIALIZED')

def doRun(dev, args):
	dev.listFilesClsObj = listFilesCls(dev,args)
	dev.listFilesClsObj.initialize()
