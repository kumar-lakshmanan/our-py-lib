'''
#For DevConsole
'''
import osa
from pysimplesoap.client import SoapClient
from pysimplesoap.simplexml import SimpleXMLElement
from xml.etree.ElementTree import fromstring
import collections 
#import defaultdict
import json

#from xmljson import badgerfish as bf
from xmljson import BadgerFish  
#bf = BadgerFish(dict_type=OrderedDict)
bf = BadgerFish()

#https://pypi.python.org/pypi/xmljson
#>>> from xmljson import badgerfish      # == xmljson.BadgerFish()
#>>> from xmljson import gdata           # == xmljson.GData()
#>>> from xmljson import parker          # == xmljson.Parker()
#>>> from xmljson import yahoo           # == xmljson.Yahoo()

url1 = 'http://www.webservicex.net/BibleWebservice.asmx?WSDL'
url = 'http://www.webservicex.net/country.asmx?WSDL'

cl = osa.Client(url)

#print(cl.types)
#print(cl.service)

currency = 'USD'

lst = cl.service.GetCountryByCurrencyCode(currency)
#rs = bf.data(fromstring(lst))
#print(rs)

bf_str1 = BadgerFish()
rs = bf_str1.data(fromstring(lst))

print(rs)
response = json.loads(json.dumps(rs))
print(response)
print('--')
print(response['NewDataSet']['Table'][0]['Name']['$'])
print(response['NewDataSet']['Table'][0]['Currency']['$'])
print(response['NewDataSet']['Table'][0]['CurrencyCode']['$'])
print(response['NewDataSet']['Table'][0]['CountryCode']['$'])
print('--')

#client = SoapClient(wsdl="http://www.webservicex.net/BibleWebservice.asmx?WSDL",trace=True)

#response = client.call('GetCurrencyByCountry',params)


#response = client.AddIntegers(a=1,b=2)
#result = response['AddResult']
#print (result)
				   