'''
#For DevConsole
'''
import threading
import time
import sqlite3


def runMe():
	for i in range(0,10):
		time.sleep(.5)
		print('ok:'+str(i))

def runMe2():
	for i in range(0,10):
		time.sleep(.8)
		print('okx:'+str(i))

z = int('25')
z2 = int('2')
x = str(z*z2)
print(x)

#dev.view.loadFinished.connect(adjustLocation)
#dev.view.titleChanged.connect(adjustTitle)
#dev.view.loadProgress.connect(setProgress)

		
		
'''		
t=threading.Thread(target=runMe,args=())
t2=threading.Thread(target=runMe2,args=())
t.start()
t2.start()
'''

