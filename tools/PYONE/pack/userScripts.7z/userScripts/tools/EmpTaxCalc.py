from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import EmpTaxCalc
#For DevConsole

class EmpTaxCalcCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=EmpTaxCalc.__file__.replace(".py",".ui")
		super(EmpTaxCalcCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)
		self.pushButton.clicked.connect(self.doRun)
		
	def initialize(self):
		self.parent.pylib.say("EmpTaxCalcClsObj is working fine")

	def doRun(self):
		income = int(self.textEdit.toPlainText())
		
		tax = 0
		if (income <= 250000):
			tax = 0
		elif (income > 250000 and income <= 500000):
			tax = 5
		elif (income > 500000 and income <= 1000000):
			tax = 20
		elif (income > 1000000):
			tax = 30
			
		ttlTax = (tax / 100) * income 
				
		self.label_2.setText('Tax Amount: ' + str(ttlTax))
		self.parent.pylib.say(ttlTax)

if (__name__=="__main__"):
	dev.EmpTaxCalcClsObj = EmpTaxCalcCls(dev)
	dev.EmpTaxCalcClsObj.show()
	dev.EmpTaxCalcClsObj.raise_()