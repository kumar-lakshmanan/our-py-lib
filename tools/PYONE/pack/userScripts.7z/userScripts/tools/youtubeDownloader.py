from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
from PyQt5.uic import loadUi
import os
import sip
import youtubeDownloader
import pyOneExternalProcess
#For DevConsole

class youtubeDownloaderCls(QtWidgets.QMainWindow):
	
	def __init__(self,parent):
		self.parent=parent 
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.uiFile=youtubeDownloader.__file__.replace(".py",".ui")
		super(youtubeDownloaderCls, self).__init__(self.parent)
		loadUi(self.uiFile, self)
		
		self.gridLayout.removeWidget(self.textEdit)
		sip.delete(self.textEdit)
		
		self.textEdit = Qsci.QsciScintilla(self.centralwidget)
		self.textEdit.setReadOnly(1)
		self.gridLayout.addWidget(self.textEdit, 0, 0, 1, 0)
		self.gridLayout.update()		
		
		self.pushButton.clicked.connect(self.doRun)
		self.pushButton_2.clicked.connect(self.doStop)
		
	def initialize(self):
		self.pyex = pyOneExternalProcess.pyOneExternalProcessCls(self.parent)
		self.youtubeApp = 'E:\\YoutubeDownloader\\bin\\youtube-dl.exe'
		self.workLoc = 'E:\\YoutubeDownloader\\bin'
		self.args=''
		self.pyex.processDisplay = self.doPrint
		self.pyex.processCompletedExternal = self.pyexStopped
		self.parent.pylib.say("youtubeDownloaderClsObj is working fine")
		self.label.setText('Waiting...')

	def pyexStopped(self, code):
		self.doPrint('\nCompleted with ' +str(code))
		self.pushButton_2.setEnabled(0)
		self.pushButton.setEnabled(0)
		self.label.setText('Completed!')
		
	def doRun(self):
	
		self.args = str(self.textEdit_2.toPlainText())
		
		self.pyex.setupExecution(self.youtubeApp,self.workLoc,self.args)
		self.pyex.executionDoStart()

		self.pushButton_2.setEnabled(1)
		self.pushButton.setEnabled(0)
		self.label.setText('Running...')
		
	def doStop(self):
		print("Terminating execution...")
		self.pyex.executionDoTerminate()
		self.pushButton_2.setEnabled(0)
		self.pushButton.setEnabled(0)
		self.label.setText('Terminated')
	
	def doPrint(self,content):
		self.textEdit.setCursorPosition(self.textEdit.lines(),0)
		self.textEdit.insert(str(content))
		vsb = self.textEdit.verticalScrollBar()
		vsb.setValue(vsb.maximum())    
		hsb = self.textEdit.horizontalScrollBar()
		hsb.setValue(0)   

	def closeEvent(self, event):
		self.doStop()
		event.accept()

if (__name__=="__main__"):
	dev.youtubeDownloaderClsObj = youtubeDownloaderCls(dev)
	dev.youtubeDownloaderClsObj.initialize()
	dev.youtubeDownloaderClsObj.show()
	dev.youtubeDownloaderClsObj.raise_()