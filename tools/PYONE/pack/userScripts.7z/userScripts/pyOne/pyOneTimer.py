'''
#For DevConsole
'''

class pyOneTimerCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.tools=self.parent.ttls		
		self.qtTools=self.parent.qtTools
		self.parent.pylib.say("pyOneTimerCls is ready!")
		
	def initialize(self):
		self.parent.pylib.say("pyOneTimerCls Initialized")
		
	def startAction(self):
		self.parent.pylib.say("-Timer Started-")
		
	def stopAction(self):
		self.parent.pylib.say("-Timer Stopped-")
	
	def timeoutAction(self):
		self.parent.pylib.say("---Timer Timed out--")

	def doRun(self):
		self.parent.pylib.say("pyOneTimerCls is working fine")

if __name__ == '__main__':
	dev.pyOneTimerClsObj = pyOneTimerCls(dev)
	dev.pyOneTimerClsObj.initialize()
