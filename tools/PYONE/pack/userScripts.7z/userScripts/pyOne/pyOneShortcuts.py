'''
#For DevConsole
#Kumaresan
'''

from PyQt5 import QtCore, QtGui, QtWidgets

import sip
import objBrowser

class pyOneShortcutsCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.settings=self.parent.settings		
		self.shortcutPair = {}
		self.parent.pylib.say("pyOneShortcutsCls is ready!")
		
	def initialize(self):
		self.parent.newToolBar = QtWidgets.QToolBar('Custom Tools',self.parent) 
		self.parent.addToolBar(self.parent.newToolBar)
		self.parent.updateTrayMenu('|')

		if(not hasattr(self.parent,'objBrowserClsObj')):		
			self.parent.objBrowserClsObj = objBrowser.objBrowserCls(self.parent)	
		
		# CHeck this url for icon names:
		# http://dev.vizuina.com/farmfresh/ 
		
		self.doQuickShortcut('ObjBrowser', self.call_objBrowser,2)	
		self.timer_tgl = self.doQuickShortcutWithIcon('Toggle Timer', None ,'time.png')   
		self.timer_tgl.setCheckable(True)		
	
		self.timer_tgl.toggled.connect(self.toggleTimer)
		self.devToggle = self.doQuickShortcutWithIcon('toggleDevMode', None, 'bios.png')
		self.devToggle.toggled.connect(self.toggleDevMode)
		self.devToggle.setCheckable(True)
	
		self.parent.pylib.say("pyOneShortcutsCls initialized!")
			
	def toggleDevMode(self, state):
		self.parent.devMode = state
		self.parent.pylib.say('Developer mode state: ' + str(state))
		
	def toggleTimer(self, state):
		if(hasattr(self.parent,'qtime')):
			if state:
				self.parent.qtime.start(1000 * self.settings.timerInterval)
				self.parent.poTimer.startAction()
			else:
				self.parent.qtime.stop()
				self.parent.poTimer.stopAction()		
	
	def call_QuickTools(self):
		import QuickTools		
		if(not hasattr(self.parent,'QuickToolsClsObj') or sip.isdeleted(self.parent.QuickToolsClsObj)):	   
			   self.parent.QuickToolsClsObj = QuickTools.QuickToolsCls(self.parent)		
		self.parent.QuickToolsClsObj.show()
		self.parent.QuickToolsClsObj.raise_()
		
	def call_objBrowser(self):
		self.parent.objBrowserClsObj.show()
		self.parent.objBrowserClsObj.raise_()
		
	def doQuickShortcut(self, label, callBackFn, type_=1):
		if(type_==1):
			return self._doShortcut(label, 'bullet_star.png', callBackFn, self.parent.newToolBar)   
		elif(type_==2):
			return self._doShortcut(label, 'bullet_red.png', callBackFn, self.parent.newToolBar)			   
		elif(type_==3):
			return self._doShortcut(label, 'bullet_purple.png', callBackFn, self.parent.newToolBar)			   
		elif(type_==4):
			return self._doShortcut(label, 'bullet_pink.png', callBackFn, self.parent.newToolBar)
			
	def doQuickShortcutWithIcon(self, label, callBackFn, icon):
		return self._doShortcut(label, icon, callBackFn, self.parent.newToolBar)
		
	def _doShortcut(self, label='text', icon='bullet_star.png', callBackFn=None, toolBar=None):
		if (label=='|'):
			self.parent.addSeparator()
			self.parent.updateTrayMenu('|')
		else:
			action = QtWidgets.QAction(self.parent)
			action.setText(label)
			if callBackFn is not None: action.triggered.connect(callBackFn)
			self.parent.qtIcon.setIcon(action, icon)
			toolBar.addAction(action)
			
			if callBackFn is not None:
				self.shortcutPair[label]=callBackFn
				self.parent.updateTrayMenu(label,self._actionContextItemClicked)	
			return action		
			
	def _actionContextItemClicked(self, *arg):
		obj = self.parent.sender()
		caller = str(obj.text())
		print("Call from " + caller)
		callBackFn = self.shortcutPair[caller]
		if(callBackFn):
			callBackFn()		
			
if __name__ == '__main__':
	dev.customShotcutsClsObj = customShotcutsCls(dev)
	#dev.customShotcutsClsObj.initializeRequiredObjects()
