'''
#For DevConsole
'''
from PyQt5 import QtCore, QtGui, Qsci, QtWidgets
import socket
import pyOneSettings
import pyOneShortcuts
import pyOneTimer
import pyOneGeneral
import pyOneRunPerDay
import os

class pyOneStartupsCls():
	
	def __init__(self,parent):
		self.parent=parent
		self.timerIntervalSec=60
		
	def initialize(self):
		self.doGeneralSetup()
		#self.doRunOncePerDaySetup()
		#self.doTimerSetup()
		#self.doShortCuts()
		#self.doAlterUI()
		#self.doUpdateContextMenu()

	def doGeneralSetup(self):
		print("Starting General Setup...")
		self.parent.pyOneSettingsClsObj=pyOneSettings.pyOneSettingsCls(self.parent)
		self.parent.pyOneSettingsClsObj.initialize()
		self.parent.settings=self.parent.pyOneSettingsClsObj
				
		self.parent.pyOneGeneralClsObj=pyOneGeneral.pyOneGeneralCls(self.parent)
		self.parent.pyOneGeneralClsObj.initialize()
		
		self.parent.pylib.say("pyOneGeneralClsObj done!")
		
	def doRunOncePerDaySetup(self):
		self.parent.pylib.say("Starting Run Once Per Day Setup...")		
		self.parent.pyOneRunPerDayClsObj=pyOneRunPerDay.pyOneRunPerDayCls(self.parent)
		self.today=self.parent.ttls.getDateTime('%Y-%m-%d')		
		if(os.path.exists('today')):
			if(self.parent.ttls.fileContent('today')==self.today):
				self.parent.pylib.say("Already executed for today!")
			else:
				self.parent.pyOneRunPerDayClsObj.initialize()
		else:
			self.parent.pyOneRunPerDayClsObj.initialize()
		self.parent.ttls.writeFileContent('today',self.today)			
		self.parent.pylib.say("pyOneRunPerDayClsObj done!")

	def doTimerSetup(self):
		self.parent.pylib.say("Starting Timer Setup...")		
		self.parent.poTimer=pyOneTimer.pyOneTimerCls(self.parent)
		self.parent.poTimer.initialize()
		self.parent.qtime=QtCore.QTimer(self.parent)
		self.parent.qtime.timeout.connect(self.parent.poTimer.timeoutAction)   
		self.parent.pylib.say("poTimer done!")

	def doShortCuts(self):
		self.parent.pylib.say("Starting Shortcuts Setup...")
		self.parent.pyOneShortcutsClsObj=pyOneShortcuts.pyOneShortcutsCls(self.parent)
		self.parent.pyOneShortcutsClsObj.initialize()
		self.parent.pylib.say("pyOneShortcutsClsObj done!")

	def doAlterUI(self):
		self.parent.pylib.say("Starting to alter the UI...")
		self.parent.qtTools.applyStyle('Windows')				
		self.parent.pylib.say("AlterUI done!")

	def doUpdateContextMenu(self):
		self.parent.pylib.say("Starting to update the context menu...")
		#self.parent.updateTrayMenu('|')
		#self.parent.updateTrayMenu('MyCalc',self._actionContextItemClicked)	
		#self.parent.updateTrayMenu('AUDGraph',self._actionContextItemClicked)	
		self.parent.pylib.say("UpdateContextMenu done!")

	def _actionContextItemClicked(self, *arg):
		obj = self.parent.sender()
		caller = str(obj.text())
		self.parent.pylib.say("Call from " + caller)
		if(caller == 'MyCalc'):
			self.parent.customShortcutsClsObj.call_Calc()
		if(caller == 'AUDGraph'):
			self.parent.customShortcutsClsObj.call_Exchangegraph()			

if __name__ == '__main__':
	dev.customStartupsClsObj = customStartupsCls(dev)
	dev.customStartupsClsObj._actionTimeOut()