import os
import shutil
# #print shutil.copy('D:/FILEIDMAGEX.PNG' , 'D:/KK.png')
#
# z = PlugMe1(self)
# z.show()
k = 103
kumar = 34

class abc():
	def __init__(self):
		self.sample
	def obj(self):
		self 

		
lst = dev.qtTools.getStyleList()

print(lst)



dev.qtTools.applyStyle('Fusion')

print(dev)

