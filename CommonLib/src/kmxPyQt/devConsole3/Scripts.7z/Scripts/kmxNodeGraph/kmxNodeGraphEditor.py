'''
Created on Jul 1, 2015

@author: MUKUND
'''

class MyClass(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        