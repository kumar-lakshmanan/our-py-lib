from PyQt5.QtCore import (Qt)
from PyQt5.QtGui import (QPainter, QBrush, QPalette)
from PyQt5.QtWidgets import (QApplication, QMainWindow, QAction, QWidget, QGraphicsScene, QGraphicsView)

import os
import sys

from PyQt5 import QtCore, QtGui, QtWidgets

class tester(QMainWindow):
    def __init__(self, parent):
        super(tester, self).__init__(parent)




widget = tester(None)
widget.show()